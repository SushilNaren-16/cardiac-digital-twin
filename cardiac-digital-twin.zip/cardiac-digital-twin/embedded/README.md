# Cardiac Digital Twin — STM32 Embedded Port

Pure-C (C99, no dynamic memory, no numpy/scipy) port of the Python simulator
(`patient_state.py`, `ecg_sim.py`, `scenarios.py`, `corrupt.py`) so it can
**run directly on an STM32 microcontroller**, not just on a laptop feeding it.

Verified: it compiles and runs correctly with plain `gcc` on a laptop
(`gcc -DTWIN_APP_HOST_TEST -IInc Src/*.c -lm`) — HR/SpO2/respiration respond
correctly across rest → walk → hypoxia → recovery. Same C code drops straight
into an STM32CubeIDE project since it only needs `<math.h>` and a hardware FPU
(any STM32F4/F7/H7/L4+ has one) — no external libraries.

## Files

| File | Role |
|---|---|
| `Core/Inc/rng.h`, `Src/rng.c` | Deterministic PRNG (xorshift32 + Box-Muller) — replaces `numpy.random` |
| `Core/Inc/patient_state.h`, `Src/patient_state.c` | Physiology layer: profiles, OU drift, coupling equations |
| `Core/Inc/ecg_sim.h`, `Src/ecg_sim.c` | ECG generator: RR/RSA synthesis + Gaussian-sum PQRST morphology |
| `Core/Inc/scenarios.h`, `Src/scenarios.c` | Timeline engine + `simulator_get_frame()` one-call API |
| `Core/Inc/corrupt.h`, `Src/corrupt.c` | Phase-3 frame-level corruption injector |
| `Core/Src/twin_app_example.c` | Example wiring into HAL (UART output + command parser for D's sliders) |

## Integrating into STM32CubeIDE

1. Create/open your CubeMX project (any STM32 with an FPU). Enable one USART
   (e.g. USART2) at 115200 baud (or higher, e.g. 921600, if you'll stream raw
   ECG samples) connected to your laptop via ST-Link VCP or an FTDI adapter.
2. Copy `Core/Inc/*.h` into your project's `Core/Inc/`, and `Core/Src/*.c`
   into `Core/Src/` (CubeIDE auto-adds new files under `Core/Src` to the build).
3. Open `twin_app_example.c`:
   - Uncomment the `#include "usart.h"` and `extern UART_HandleTypeDef huart2;`
     lines, and replace the body of `uart_send_line()` with the real
     `HAL_UART_Transmit(&huart2, ...)` call (shown commented above it).
   - In your real `main.c`, inside `/* USER CODE BEGIN 2 */`, call
     `twin_app_init();`.
   - Inside your main `while(1)` loop (or a 1 Hz `TIM` interrupt callback),
     call `twin_app_tick();` once per second.
   - Wire your UART RX interrupt (or `HAL_UARTEx_ReceiveToIdle_IT`) to collect
     incoming lines from D's laptop and call
     `twin_app_handle_command(line)` for each complete line.
4. Build and flash as normal (`STM32CubeIDE: Run/Debug`).

## What "Done when" looks like here

`simulator_get_frame()` called once per second for a `demo_3min()` timeline
gives coherent shared-dict vitals + ECG for the full 3(or 5)-minute script —
same contract as the Python `get_frame()`. Verified output (see above) shows
HR rising with activity, SpO2 dropping and HR compensating during the
hypoxia segment, then both recovering — exactly the coupling rules required.

## Performance note

At 1 Hz, each call does:
- ~10 float ops for physiology (`patient_state_step`)
- ECG: up to ~8 pending beats × 250 samples × ~5 Gaussians = a few thousand
  `expf()` calls per second

This is trivial for any Cortex-M4F/M7 running at even 48–84 MHz — nowhere
close to real-time budget. No need for fixed-point tricks or lookup tables
unless you're on a Cortex-M0 (no FPU); in that case, precomputed Gaussian
lookup tables would be the next optimization step.

## What is intentionally left on the laptop side

- `docs`/dataset generation for Person C (`data/*.csv`) — that's a one-time
  offline batch job, better done in Python with pandas.
- Full sample-level ECG corruption (noise bursts, sample loss, multirate
  resampling) for scoring the fusion layer — run the original `corrupt.py`
  on the laptop against CSVs this firmware logs over UART. The STM32-side
  `corrupt.c` here only does lightweight frame-level corruption, useful if
  you want the device itself to demo a "noisy sensor" live.
