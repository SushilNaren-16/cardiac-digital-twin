#include "corrupt.h"
#include <string.h>

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

void corruptor_init(Corruptor *c, float level, uint32_t seed) {
    memset(c, 0, sizeof(*c));
    c->level = clampf(level, 0.0f, 0.5f);
    rng_seed(&c->rng, seed);
}

static uint8_t maybe_corrupt(Corruptor *c, float *value, float stale_value, uint8_t have_stale) {
    if (rng_uniform(&c->rng) >= c->level) return 1; /* untouched, valid */
    float roll = rng_uniform(&c->rng);
    if (roll < 0.5f) {                 /* drop */
        return 0;
    } else if (roll < 0.8f) {          /* spike */
        static const float mults[4] = {0.4f, 0.6f, 1.6f, 2.2f};
        int idx = rng_int_range(&c->rng, 0, 4);
        *value = *value * mults[idx];
        return 1;
    } else {                            /* stale */
        if (have_stale) *value = stale_value;
        return 1;
    }
}

void corruptor_apply(Corruptor *c, Frame *f, CorruptValidity *valid_out) {
    CorruptValidity v;
    v.hr_valid       = maybe_corrupt(c, &f->hr,       c->stale_hr,       c->have_stale);
    v.rr_valid       = maybe_corrupt(c, &f->rr,       c->stale_rr,       c->have_stale);
    v.hrv_valid      = maybe_corrupt(c, &f->hrv,      c->stale_hrv,      c->have_stale);
    v.temp_valid     = maybe_corrupt(c, &f->temp,     c->stale_temp,     c->have_stale);
    v.resp_valid     = maybe_corrupt(c, &f->resp,     c->stale_resp,     c->have_stale);
    v.spo2_valid     = maybe_corrupt(c, &f->spo2,     c->stale_spo2,     c->have_stale);
    v.bp_valid       = maybe_corrupt(c, &f->bp,       c->stale_bp,       c->have_stale);
    v.activity_valid = maybe_corrupt(c, &f->activity, c->stale_activity, c->have_stale);

    /* leads-off flag flips occasionally at high corruption */
    if (rng_uniform(&c->rng) < c->level * 0.3f) {
        f->leads_ok = 0;
        v.hr_valid = v.rr_valid = v.hrv_valid = 0;
    }

    c->stale_hr = f->hr; c->stale_rr = f->rr; c->stale_hrv = f->hrv; c->stale_temp = f->temp;
    c->stale_resp = f->resp; c->stale_spo2 = f->spo2; c->stale_bp = f->bp;
    c->stale_activity = f->activity;
    c->have_stale = 1;

    if (valid_out) *valid_out = v;
}
