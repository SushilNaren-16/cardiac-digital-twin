/*
 * twin_app_example.c
 *
 * Example of how to wire the digital-twin modules into a normal
 * STM32CubeIDE / STM32CubeMX HAL project. This file is NOT a complete
 * main.c -- copy the pieces you need into your CubeMX-generated main.c,
 * inside the USER CODE sections, alongside your existing SystemClock_Config()
 * / MX_GPIO_Init() / MX_USART2_UART_Init() calls.
 *
 * Assumed CubeMX setup:
 *   - USART2 (or any UART) configured, e.g. 115200-8-N-1, connected to
 *     D's laptop (via ST-Link VCP or an FTDI adapter).
 *   - A hardware timer (e.g. TIM2) generating a 1 Hz interrupt, OR simply
 *     a HAL_Delay(1000) loop if you don't need drift-free timing.
 *   - `extern UART_HandleTypeDef huart2;` from usart.c
 *
 * What this example does each second:
 *   1. Advances the simulator by 1 s -> Frame (shared dict + ecg + beats)
 *   2. Sends the shared-dict fields as one CSV line over UART (for logging /
 *      for Person C's fusion layer to read on the laptop)
 *   3. Sends each new beat as a "B,..." line (matches docs/protocol.md)
 *   4. Polls the UART receive buffer for simple text commands from D's
 *      laptop (the what-if sliders) and applies them live
 */

#include "scenarios.h"
#include "corrupt.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* #include "usart.h"      -- uncomment in your real project */
/* extern UART_HandleTypeDef huart2; */

static Simulator sim;
static Corruptor corruptor;
static uint8_t use_corruption = 0; /* Phase 3: flip on to fuzz the stream */

/* ---- stand-ins for your real HAL calls; replace bodies with HAL_UART_Transmit ---- */
static void uart_send_line(const char *line) {
    /* HAL_UART_Transmit(&huart2, (uint8_t*)line, strlen(line), HAL_MAX_DELAY);
       HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n", 2, HAL_MAX_DELAY); */
    printf("%s\r\n", line); /* for host-side testing without hardware */
}

/* Call once at startup (e.g. from main(), after MX_*_Init calls) */
void twin_app_init(void) {
    Timeline tl = demo_3min();          /* or demo_5min() for the full 5-min script */
    simulator_init(&sim, PROFILE_AVERAGE, tl, /*shadow_enabled=*/1, "simulated");
    corruptor_init(&corruptor, 0.0f, 42);
}

/* Call once per second (from a 1 Hz timer ISR, or a HAL_Delay(1000) loop) */
void twin_app_tick(void) {
    Frame f = simulator_get_frame(&sim);

    if (use_corruption) {
        CorruptValidity valid;
        corruptor_apply(&corruptor, &f, &valid);
        /* fields with *_valid == 0 were "dropped" -- you'd send a sentinel
           (e.g. empty field) instead of the number for those, if desired */
    }

    /* ---- 1) shared-dict line: t,hr,rr,hrv,temp,resp,spo2,bp,activity,leads_ok,source,label */
    char line[160];
    snprintf(line, sizeof(line),
             "%.1f,%.1f,%.1f,%.1f,%.2f,%.1f,%.1f,%.1f,%.3f,%d,%s,%s",
             f.t, f.hr, f.rr, f.hrv, f.temp, f.resp, f.spo2, f.bp,
             f.activity, (int)f.leads_ok, f.source, f.label);
    uart_send_line(line);

    /* ---- 2) one B,... line per new heartbeat this second ---- */
    for (int i = 0; i < f.beat_count; i++) {
        char bline[64];
        simulator_beat_line(&f, f.temp, bline, sizeof(bline), &f.beats[i]);
        uart_send_line(bline);
    }

    /* ---- 3) raw ECG samples, if you want to stream/log the waveform too ----
       At 250 Hz this is 250 floats/second; typically only enable this if you
       have a fast enough UART baud rate (e.g. 921600) or you DAC-replay it:
       for (int i = 0; i < ECG_SAMPLES_PER_SEC; i++) {
           uint16_t counts = ecg_to_adc_counts(f.ecg[i], 12, 100.0f, 3.3f);
           // HAL_DAC_SetValue(...) or buffer for a later burst UART send
       }
    */
}

/*
 * Very small command parser for D's what-if sliders, arriving as UART text
 * lines such as:
 *   ACT 0.7          -> simulator_set_activity(0.7)
 *   SPO2 88           -> simulator_set_spo2_target(88)
 *   ARR AFIB          -> simulator_set_arrhythmia(ARR_AFIB)   (NONE|PVC|AFIB|TACHY|BRADY)
 *   BP 25             -> simulator_set_bp_offset(25)
 *   SLEEP 1           -> simulator_set_sleep(1)
 *   LEADOFF 1         -> simulator_set_lead_off(1)
 *   CLEAR             -> simulator_clear_overrides()
 *   CORRUPT 0.2       -> set corruption level (Phase 3), 0 disables it
 *
 * Call this from your UART RX interrupt/idle-line handler with each
 * complete line received (already null-terminated).
 */
void twin_app_handle_command(char *line) {
    char cmd[16] = {0};
    float arg = 0.0f;
    int n = sscanf(line, "%15s %f", cmd, &arg);

    if (strcmp(cmd, "ACT") == 0 && n == 2) {
        simulator_set_activity(&sim, arg);
    } else if (strcmp(cmd, "SPO2") == 0 && n == 2) {
        simulator_set_spo2_target(&sim, arg);
    } else if (strcmp(cmd, "BP") == 0 && n == 2) {
        simulator_set_bp_offset(&sim, arg);
    } else if (strcmp(cmd, "SLEEP") == 0 && n == 2) {
        simulator_set_sleep(&sim, arg != 0.0f);
    } else if (strcmp(cmd, "LEADOFF") == 0 && n == 2) {
        simulator_set_lead_off(&sim, arg != 0.0f);
    } else if (strcmp(cmd, "CORRUPT") == 0 && n == 2) {
        use_corruption = (arg > 0.0f);
        corruptor_init(&corruptor, arg, 42);
    } else if (strcmp(cmd, "CLEAR") == 0) {
        simulator_clear_overrides(&sim);
    } else if (strcmp(cmd, "ARR") == 0) {
        char kind[16] = {0};
        sscanf(line, "%*s %15s", kind);
        if (strcmp(kind, "NONE") == 0)       simulator_clear_arrhythmia(&sim);
        else if (strcmp(kind, "PVC") == 0)   simulator_set_arrhythmia(&sim, ARR_PVC);
        else if (strcmp(kind, "AFIB") == 0)  simulator_set_arrhythmia(&sim, ARR_AFIB);
        else if (strcmp(kind, "TACHY") == 0) simulator_set_arrhythmia(&sim, ARR_TACHY);
        else if (strcmp(kind, "BRADY") == 0) simulator_set_arrhythmia(&sim, ARR_BRADY);
    }
}

#ifdef TWIN_APP_HOST_TEST
/* Build this file alone on your laptop (gcc) to sanity-check the algorithm
 * before flashing, since it prints instead of using HAL:
 *   gcc -DTWIN_APP_HOST_TEST -I../Inc *.c -lm -o twin_test && ./twin_test
 */
int main(void) {
    twin_app_init();
    for (int s = 0; s < 180; s++) {
        twin_app_tick();
    }
    return 0;
}
#endif
