#include "rng.h"
#include <math.h>

void rng_seed(Rng *r, uint32_t seed) {
    r->state = seed ? seed : 0xA5A5A5A5u;
    r->has_spare = 0;
    r->spare = 0.0f;
}

static uint32_t xorshift32(uint32_t *state) {
    uint32_t x = *state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return x;
}

float rng_uniform(Rng *r) {
    /* 24 significant bits -> [0,1) */
    return (float)(xorshift32(&r->state) >> 8) / (float)(1u << 24);
}

float rng_uniform_range(Rng *r, float lo, float hi) {
    return lo + (hi - lo) * rng_uniform(r);
}

float rng_normal(Rng *r) {
    if (r->has_spare) {
        r->has_spare = 0;
        return r->spare;
    }
    float u1, u2, s;
    do {
        u1 = 2.0f * rng_uniform(r) - 1.0f;
        u2 = 2.0f * rng_uniform(r) - 1.0f;
        s = u1 * u1 + u2 * u2;
    } while (s >= 1.0f || s == 0.0f);
    float mul = sqrtf(-2.0f * logf(s) / s);
    r->spare = u2 * mul;
    r->has_spare = 1;
    return u1 * mul;
}

int rng_poisson(Rng *r, float lambda) {
    /* Knuth's algorithm - fine for the small lambdas used here (<5) */
    if (lambda <= 0.0f) return 0;
    float L = expf(-lambda);
    int k = 0;
    float p = 1.0f;
    do {
        k++;
        p *= rng_uniform(r);
    } while (p > L);
    return k - 1;
}

int rng_int_range(Rng *r, int lo, int hi_exclusive) {
    if (hi_exclusive <= lo) return lo;
    int span = hi_exclusive - lo;
    return lo + (int)(rng_uniform(r) * (float)span);
}
