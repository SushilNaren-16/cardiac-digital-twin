#include "scenarios.h"
#include <math.h>
#include <string.h>
#include <stdio.h>

static float clampf(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

/* ============================== Timeline ============================== */
void timeline_init(Timeline *tl, const char *name) {
    tl->name = name;
    tl->count = 0;
    tl->duration = 0.0f;
}

void timeline_add(Timeline *tl, const char *label, float seconds,
                   float activity, float hypoxia, uint8_t sleep,
                   Arrhythmia arrhythmia, uint8_t lead_off, float bp_offset) {
    if (tl->count >= TIMELINE_MAX_SEGMENTS) return; /* silently ignore overflow */
    Segment *s = &tl->segments[tl->count++];
    s->start = tl->duration;
    s->end = tl->duration + seconds;
    s->label = label;
    s->activity = activity;
    s->hypoxia = hypoxia;
    s->sleep = sleep;
    s->arrhythmia = arrhythmia;
    s->lead_off = lead_off;
    s->bp_offset = bp_offset;
    tl->duration += seconds;
}

static const Segment REST_FALLBACK = {0, 1, "rest", 0, 0, 0, ARR_NONE, 0, 0};

const Segment *timeline_at(const Timeline *tl, float t) {
    for (int i = 0; i < tl->count; i++) {
        if (tl->segments[i].start <= t && t < tl->segments[i].end) {
            return &tl->segments[i];
        }
    }
    return &REST_FALLBACK; /* after the script ends: rest */
}

/* ---- ready-made scripts (mirrors scenarios.py) ---- */
Timeline demo_3min(void) {
    Timeline tl;
    timeline_init(&tl, "demo_3min");
    timeline_add(&tl, "rest",     45, 0.0f, 0, 0, ARR_NONE, 0, 0);
    timeline_add(&tl, "walking",  45, 0.5f, 0, 0, ARR_NONE, 0, 0);
    timeline_add(&tl, "recovery", 15, 0.0f, 0, 0, ARR_NONE, 0, 0);
    timeline_add(&tl, "hypoxia",  45, 0.0f, 0.9f, 0, ARR_NONE, 0, 0);
    timeline_add(&tl, "recovery", 30, 0.0f, 0, 0, ARR_NONE, 0, 0);
    return tl;
}

Timeline demo_5min(void) {
    Timeline tl;
    timeline_init(&tl, "demo_5min");
    timeline_add(&tl, "rest",     60, 0.0f, 0,     0, ARR_NONE,  0, 0);
    timeline_add(&tl, "walking",  60, 0.5f, 0,     0, ARR_NONE,  0, 0);
    timeline_add(&tl, "recovery", 30, 0.0f, 0,     0, ARR_NONE,  0, 0);
    timeline_add(&tl, "hypoxia",  60, 0.0f, 0.9f,  0, ARR_NONE,  0, 0);
    timeline_add(&tl, "recovery", 30, 0.0f, 0,     0, ARR_NONE,  0, 0);
    timeline_add(&tl, "pvc",      30, 0.0f, 0,     0, ARR_PVC,   0, 0);
    timeline_add(&tl, "afib",     20, 0.0f, 0,     0, ARR_AFIB,  0, 0);
    timeline_add(&tl, "recovery", 10, 0.0f, 0,     0, ARR_NONE,  0, 0);
    return tl;
}

Timeline sleep_demo(void) {
    Timeline tl;
    timeline_init(&tl, "sleep_demo");
    timeline_add(&tl, "rest",   60,  0.0f, 0, 0, ARR_NONE, 0, 0);
    timeline_add(&tl, "sleep", 180,  0.0f, 0, 1, ARR_NONE, 0, 0);
    timeline_add(&tl, "waking", 60,  0.0f, 0, 0, ARR_NONE, 0, 0);
    return tl;
}

/* ============================== Simulator ============================== */
void simulator_init(Simulator *sim, PatientProfile profile, Timeline timeline,
                     int shadow_enabled, const char *source) {
    memset(sim, 0, sizeof(*sim));
    sim->profile = profile;
    sim->timeline = timeline;
    patient_state_init(&sim->state, profile);
    sim->shadow_enabled = (uint8_t)shadow_enabled;
    if (shadow_enabled) {
        patient_state_init(&sim->shadow, profile);
    }
    ecg_synth_init(&sim->ecg, ECG_FS, profile.seed, profile.noise, 50.0f);
    rng_seed(&sim->rng, profile.seed + 777u);
    sim->last_hr = profile.hr0;
    sim->last_rr = 60000.0f / profile.hr0;
    sim->last_hrv = profile.hrv0;
    sim->t = 0.0f;
    sim->source = source;
}

/* ---- live controls ---- */
void simulator_set_activity(Simulator *sim, float activity) {
    sim->overrides.activity_set = 1;
    sim->overrides.activity = clampf(activity, 0.0f, 1.0f);
    sim->overrides.any_set = 1;
}
void simulator_inject_hypoxia(Simulator *sim, float severity) {
    sim->overrides.hypoxia_set = 1;
    sim->overrides.hypoxia = clampf(severity, 0.0f, 1.0f);
    sim->overrides.any_set = 1;
}
void simulator_clear_hypoxia(Simulator *sim) {
    simulator_inject_hypoxia(sim, 0.0f);
}
void simulator_set_spo2_target(Simulator *sim, float spo2_pct) {
    float act = sim->overrides.activity_set ? sim->overrides.activity
                                             : timeline_at(&sim->timeline, sim->t)->activity;
    float sev = (sim->profile.spo2_base - 1.2f * act - spo2_pct) / 14.0f;
    simulator_inject_hypoxia(sim, sev);
}
void simulator_set_arrhythmia(Simulator *sim, Arrhythmia kind) {
    sim->overrides.arrhythmia_set = 1;
    sim->overrides.arrhythmia = kind;
    sim->overrides.any_set = 1;
}
void simulator_clear_arrhythmia(Simulator *sim) {
    simulator_set_arrhythmia(sim, ARR_NONE);
}
void simulator_set_sleep(Simulator *sim, uint8_t sleep) {
    sim->overrides.sleep_set = 1;
    sim->overrides.sleep = sleep;
    sim->overrides.any_set = 1;
}
void simulator_set_lead_off(Simulator *sim, uint8_t on) {
    sim->overrides.lead_off_set = 1;
    sim->overrides.lead_off = on;
    sim->overrides.any_set = 1;
}
void simulator_set_bp_offset(Simulator *sim, float mmhg) {
    sim->overrides.bp_offset_set = 1;
    sim->overrides.bp_offset = mmhg;
    sim->overrides.any_set = 1;
}
void simulator_clear_overrides(Simulator *sim) {
    memset(&sim->overrides, 0, sizeof(sim->overrides));
}

static void current_inputs(Simulator *sim, const Segment **seg_out,
                            float *activity, float *hypoxia, uint8_t *sleep,
                            Arrhythmia *arrhythmia, uint8_t *lead_off, float *bp_offset) {
    const Segment *seg = timeline_at(&sim->timeline, sim->t);
    *seg_out = seg;
    *activity   = sim->overrides.activity_set   ? sim->overrides.activity   : seg->activity;
    *hypoxia    = sim->overrides.hypoxia_set    ? sim->overrides.hypoxia    : seg->hypoxia;
    *sleep      = sim->overrides.sleep_set      ? sim->overrides.sleep      : seg->sleep;
    *arrhythmia = sim->overrides.arrhythmia_set ? sim->overrides.arrhythmia : seg->arrhythmia;
    *lead_off   = sim->overrides.lead_off_set   ? sim->overrides.lead_off   : seg->lead_off;
    *bp_offset  = sim->overrides.bp_offset_set  ? sim->overrides.bp_offset  : seg->bp_offset;
}

static void rr_hist_push(Simulator *sim, float rr_ms) {
    sim->rr_hist[sim->rr_hist_head] = rr_ms;
    sim->rr_hist_head = (sim->rr_hist_head + 1) % RR_HIST_LEN;
    if (sim->rr_hist_count < RR_HIST_LEN) sim->rr_hist_count++;
}

/* mean of the last `n` pushed RR values (most recent), n <= rr_hist_count */
static float rr_hist_mean_last(const Simulator *sim, int n) {
    if (n > sim->rr_hist_count) n = sim->rr_hist_count;
    if (n <= 0) return 0.0f;
    float sum = 0.0f;
    int idx = sim->rr_hist_head;
    for (int i = 0; i < n; i++) {
        idx = (idx - 1 + RR_HIST_LEN) % RR_HIST_LEN;
        sum += sim->rr_hist[idx];
    }
    return sum / (float)n;
}

/* RMSSD over all currently-held history (successive differences) */
static float rr_hist_rmssd(const Simulator *sim) {
    int n = sim->rr_hist_count;
    if (n < 2) return 0.0f;
    /* reconstruct chronological order into a small local buffer */
    float buf[RR_HIST_LEN];
    int idx = sim->rr_hist_head;
    for (int i = n - 1; i >= 0; i--) {
        idx = (idx - 1 + RR_HIST_LEN) % RR_HIST_LEN;
        buf[i] = sim->rr_hist[idx];
    }
    float ssum = 0.0f;
    for (int i = 1; i < n; i++) {
        float d = buf[i] - buf[i - 1];
        ssum += d * d;
    }
    return sqrtf(ssum / (float)(n - 1));
}

Frame simulator_get_frame(Simulator *sim) {
    const Segment *seg;
    float activity, hypoxia, bp_offset;
    uint8_t sleep, lead_off;
    Arrhythmia arrhythmia;
    current_inputs(sim, &seg, &activity, &hypoxia, &sleep, &arrhythmia, &lead_off, &bp_offset);

    TruthFrame truth = patient_state_step(&sim->state, activity, hypoxia, sleep,
                                           arrhythmia, bp_offset, 1.0f);
    if (sim->shadow_enabled) {
        (void)patient_state_step(&sim->shadow, activity, 0.0f, sleep, ARR_NONE, bp_offset, 1.0f);
    }

    Frame f;
    memset(&f, 0, sizeof(f));

    EcgBeat new_beats[ECG_MAX_NEW_BEATS];
    int n_new = ecg_synth_render_1s(&sim->ecg, truth.hr, truth.hrv, truth.resp,
                                     arrhythmia, truth.activity, lead_off,
                                     f.ecg, new_beats);
    if (lead_off) n_new = 0; /* electrode off: the detector sees no beats */

    for (int i = 0; i < n_new; i++) {
        rr_hist_push(sim, new_beats[i].rr_ms);
        f.beats[i] = new_beats[i];
    }
    f.beat_count = n_new;

    /* ---- what an STM32 would actually MEASURE from the generated ECG ---- */
    float meas_hr, meas_rr, meas_hrv;
    if (lead_off) {
        meas_hr = sim->last_hr; meas_rr = sim->last_rr; meas_hrv = sim->last_hrv;
    } else if (sim->rr_hist_count < 3) {
        meas_hr = truth.hr; meas_rr = truth.rr; meas_hrv = truth.hrv;
    } else {
        float rr_mean = rr_hist_mean_last(sim, 5);
        meas_hr = 60000.0f / rr_mean;
        meas_rr = rr_mean;
        meas_hrv = rr_hist_rmssd(sim);
    }
    if (!lead_off) {
        sim->last_hr = meas_hr; sim->last_rr = meas_rr; sim->last_hrv = meas_hrv;
    }

    float n = sim->profile.noise;
    f.t = truth.t;
    f.hr = meas_hr;
    f.rr = meas_rr;
    f.hrv = meas_hrv;
    f.temp = truth.temp + rng_normal(&sim->rng) * 0.03f * n;
    f.resp = truth.resp + rng_normal(&sim->rng) * 0.5f * n;
    f.spo2 = clampf(truth.spo2 + rng_normal(&sim->rng) * 0.4f * n, 0.0f, 100.0f);
    f.bp   = truth.bp + rng_normal(&sim->rng) * 2.0f * n;
    f.activity = clampf(truth.activity + rng_normal(&sim->rng) * 0.02f * n, 0.0f, 1.0f);
    f.leads_ok = !lead_off;
    f.source = sim->source;
    f.label = seg->label;

    sim->t = truth.t;
    return f;
}

int simulator_beat_line(const Frame *f, float temp, char *buf, int buf_size,
                         const EcgBeat *b) {
    return snprintf(buf, (size_t)buf_size, "B,%d,%d,%.0f,%.0f,%.1f,%d",
                     (int)b->t_ms, (int)(b->rr_ms + 0.5f), f->hr, f->hrv, temp,
                     (int)f->leads_ok);
}
