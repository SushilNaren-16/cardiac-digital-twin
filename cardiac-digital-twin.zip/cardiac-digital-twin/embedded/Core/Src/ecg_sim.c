#include "ecg_sim.h"
#include <math.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

static float clampf(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

void ecg_synth_init(EcgSynth *e, int fs, uint32_t seed, float noise, float mains_hz) {
    memset(e, 0, sizeof(*e));
    e->fs = fs;
    rng_seed(&e->rng, seed + 12345u);
    e->noise = noise;
    e->mains_hz = mains_hz;
    e->t = 0.0f;
    e->next_r = 0.35f;
    e->rsa_phase = 0.0f;
    e->forced_rr_valid = 0;
    e->resp_phase = 0.0f;
    e->motion_zi = 0.0f;
    e->last_rr = 60000.0f / 70.0f;
}

/* ---- RR interval generation: returns rr(ms) and kind of the NEXT beat ---- */
static float next_rr(EcgSynth *e, float hr, float hrv, float resp, Arrhythmia rhythm,
                      Arrhythmia *kind_out) {
    float base = 60000.0f / (hr > 30.0f ? hr : 30.0f);

    if (e->forced_rr_valid) {                 /* compensatory pause after PVC */
        e->forced_rr_valid = 0;
        *kind_out = ARR_NONE;
        return e->forced_rr;
    }

    if (rhythm == ARR_AFIB) {                 /* irregularly irregular */
        float s = (hrv / sqrtf(2.0f)) / (base > 1.0f ? base : 1.0f);
        s = clampf(s, 0.08f, 0.35f);
        float rr = base * expf(rng_normal(&e->rng) * s);
        *kind_out = ARR_AFIB;
        return clampf(rr, 280.0f, 1600.0f);
    }

    /* normal sinus rhythm with RSA + jitter, calibrated to RMSSD ~ hrv */
    float f = resp / 60.0f;
    float k = fmaxf(sqrtf(2.0f) * fabsf(sinf(M_PI * f * base / 1000.0f)), 0.35f);
    float rsa_amp = (hrv * sqrtf(0.6f)) / k;
    float jit_sd = (hrv * sqrtf(0.4f)) / sqrtf(2.0f);
    e->rsa_phase += 2.0f * M_PI * f * base / 1000.0f;
    float rr = base + rsa_amp * sinf(e->rsa_phase) + rng_normal(&e->rng) * jit_sd;
    rr = clampf(rr, 0.55f * base, 1.6f * base);

    if (rhythm == ARR_PVC && rng_uniform(&e->rng) < 0.10f) {
        float pause = 2.0f * base - 0.62f * base;
        e->forced_rr = fmaxf(pause, 0.6f * base);
        e->forced_rr_valid = 1;
        *kind_out = ARR_PVC;
        return 0.62f * base;                  /* premature beat */
    }
    *kind_out = ARR_NONE;
    return rr;
}

/* ---- beat morphology: sum of Gaussians (P,Q,R,S,T), mV, at time tau (s) rel. R peak ---- */
static float beat_contrib(float tau, float rr_s, Arrhythmia kind) {
    float sq = sqrtf(rr_s);
    float g;
    if (kind == ARR_PVC) {
        float d;
        d = (tau - 0.0f) / 0.028f;         g  = 1.25f * expf(-0.5f * d * d);
        d = (tau - 0.055f) / 0.030f;       g += -0.45f * expf(-0.5f * d * d);
        d = (tau - 0.30f * sq) / 0.065f;   g += -0.45f * expf(-0.5f * d * d);
        return g;
    }
    float d;
    d = (tau - 0.0f) / 0.010f;                 g  = 1.00f * expf(-0.5f * d * d);
    d = (tau - (-0.036f)) / 0.008f;            g += -0.10f * expf(-0.5f * d * d);
    d = (tau - 0.030f) / 0.009f;               g += -0.22f * expf(-0.5f * d * d);
    d = (tau - 0.27f * sq) / (0.045f * sq);    g += 0.30f * expf(-0.5f * d * d);
    if (kind != ARR_AFIB) {
        d = (tau - (-0.17f * sq)) / 0.022f;    g += 0.12f * expf(-0.5f * d * d); /* P wave */
    }
    return g;
}

int ecg_synth_render_1s(EcgSynth *e, float hr, float hrv, float resp,
                         Arrhythmia rhythm, float activity, uint8_t lead_off,
                         float *out_ecg, EcgBeat *out_beats) {
    int fs = e->fs;
    int n = fs; /* exactly 1 second */
    float t0 = e->t, t1 = e->t + 1.0f;

    /* schedule beats a little beyond the chunk so T waves complete */
    while (e->next_r < t1 + 0.8f) {
        int slot = -1;
        for (int i = 0; i < ECG_MAX_PENDING_BEATS; i++) {
            if (!e->beats[i].used) { slot = i; break; }
        }
        Arrhythmia kind;
        float rr_ms = next_rr(e, hr, hrv, resp, rhythm, &kind);
        if (slot >= 0) {
            e->beats[slot].t = e->next_r;
            e->beats[slot].rr = rr_ms;
            e->beats[slot].kind = kind;
            e->beats[slot].used = 1;
        } /* if the fixed buffer is full, oldest beats are already flushed below each call */
        e->next_r += rr_ms / 1000.0f;
    }

    for (int i = 0; i < n; i++) out_ecg[i] = 0.0f;

    int new_count = 0;
    for (int i = 0; i < ECG_MAX_PENDING_BEATS; i++) {
        if (!e->beats[i].used) continue;
        float bt = e->beats[i].t;
        if (bt >= t0 - 0.7f && bt < t1 + 0.7f) {
            float rr_s = fmaxf(e->beats[i].rr, 400.0f) / 1000.0f;
            for (int s = 0; s < n; s++) {
                float ts = t0 + (float)s / (float)fs;
                out_ecg[s] += beat_contrib(ts - bt, rr_s, e->beats[i].kind);
            }
        }
        if (bt >= t0 && bt < t1 && new_count < ECG_MAX_NEW_BEATS) {
            out_beats[new_count].t_ms = bt * 1000.0f;
            out_beats[new_count].rr_ms = e->beats[i].rr;
            out_beats[new_count].kind = e->beats[i].kind;
            new_count++;
        }
        if (bt <= t0 - 1.0f) {
            e->beats[i].used = 0;   /* drop beats we no longer need */
        }
    }

    if (rhythm == ARR_AFIB) {       /* fibrillatory f-waves */
        float amp = 0.6f + 0.4f * rng_uniform(&e->rng);
        for (int s = 0; s < n; s++) {
            float ts = t0 + (float)s / (float)fs;
            out_ecg[s] += 0.03f * sinf(2.0f * M_PI * 6.0f * ts + 1.3f) * amp;
        }
    }

    /* ---- baseline wander (slow + respiration-linked) */
    float f_resp = resp / 60.0f;
    for (int s = 0; s < n; s++) {
        float ts = t0 + (float)s / (float)fs;
        float ph = e->resp_phase + 2.0f * M_PI * f_resp * (float)s / (float)fs;
        out_ecg[s] += 0.10f * sinf(2.0f * M_PI * 0.17f * ts + 0.7f) + 0.05f * sinf(ph);
    }
    e->resp_phase = fmodf(e->resp_phase + 2.0f * M_PI * f_resp * (float)n / (float)fs,
                           2.0f * M_PI);

    /* ---- noise: white + mains hum + motion artifact (grows with activity) */
    for (int s = 0; s < n; s++) {
        float ts = t0 + (float)s / (float)fs;
        out_ecg[s] += rng_normal(&e->rng) * 0.015f * e->noise;
        out_ecg[s] += 0.01f * e->noise * sinf(2.0f * M_PI * e->mains_hz * ts);
    }
    if (activity > 0.05f) {
        float slow = e->motion_zi;
        for (int s = 0; s < n; s++) {
            float w = rng_normal(&e->rng);
            slow = 0.02f * w + 0.98f * slow;    /* single-pole low-pass, same as lfilter([0.02],[1,-0.98]) */
            out_ecg[s] += (3.0f * activity * activity) * slow;
        }
        e->motion_zi = slow;
        if (activity > 0.4f && rng_uniform(&e->rng) < 0.25f * activity) {
            int i0 = rng_int_range(&e->rng, 0, (n - 20) > 0 ? (n - 20) : 1);
            int len = (20 < (n - i0)) ? 20 : (n - i0);
            for (int k = 0; k < len; k++) {
                out_ecg[i0 + k] += rng_normal(&e->rng) * 0.25f * activity;
            }
        }
    }

    if (lead_off) {                             /* electrode disconnected: railed + hum */
        for (int s = 0; s < n; s++) {
            float ts = t0 + (float)s / (float)fs;
            out_ecg[s] = 0.02f * sinf(2.0f * M_PI * e->mains_hz * ts)
                       + 0.005f * rng_normal(&e->rng) + 1.4f;
        }
    }

    e->t = t1;
    if (new_count > 0) e->last_rr = out_beats[new_count - 1].rr_ms;
    return new_count;
}

uint16_t ecg_to_adc_counts(float ecg_mv, int bits, float gain, float vref) {
    float volts = 1.5f + ecg_mv * 1e-3f * gain;
    float max_count = (float)((1 << bits) - 1);
    float counts = roundf(volts / vref * max_count);
    counts = clampf(counts, 0.0f, max_count);
    return (uint16_t)counts;
}
