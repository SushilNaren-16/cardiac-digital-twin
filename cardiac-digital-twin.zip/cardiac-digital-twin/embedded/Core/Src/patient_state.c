#include "patient_state.h"
#include <math.h>

const PatientProfile PROFILE_ATHLETE = {
    "athlete", 55.0f, 70.0f, 35.0f, 1.2f, 99.0f, 110.0f, 12.0f, 36.5f, 0.08f, 1.0f, 1
};
const PatientProfile PROFILE_AVERAGE = {
    "average", 70.0f, 50.0f, 50.0f, 1.6f, 98.0f, 120.0f, 14.0f, 36.7f, 0.15f, 1.0f, 2
};
const PatientProfile PROFILE_ANXIOUS = {
    "anxious", 82.0f, 25.0f, 55.0f, 2.0f, 97.0f, 135.0f, 16.0f, 36.9f, 0.22f, 1.0f, 3
};

float approach(float x, float target, float tau, float dt) {
    return x + (target - x) * (1.0f - expf(-dt / tau));
}

void ou_init(OU *o, float tau, float sigma) {
    o->tau = tau;
    o->sigma = sigma;
    o->x = 0.0f;
}

float ou_step(OU *o, float z, float dt) {
    o->x += -o->x / o->tau * dt + o->sigma * sqrtf(dt) * z;
    return o->x;
}

static float clampf(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

void patient_state_init(PatientState *ps, PatientProfile profile) {
    ps->p = profile;
    rng_seed(&ps->rng, profile.seed);
    ps->t = 0.0f;
    ps->act = 0.0f;
    ps->resp = profile.resp_base;
    ps->spo2 = profile.spo2_base;
    ps->hr = profile.hr0;
    ps->sbp = profile.bp_base;
    ps->temp = profile.temp_base;
    ps->fatigue_state = 0.0f;
    ps->hrv = profile.hrv0;
    ou_init(&ps->d_hr,   90.0f, 0.6f);
    ou_init(&ps->d_resp, 60.0f, 0.15f);
    ou_init(&ps->d_bp,  120.0f, 0.5f);
    ou_init(&ps->d_temp, 300.0f, 0.01f);
    ou_init(&ps->d_spo2, 60.0f, 0.08f);
}

TruthFrame patient_state_step(PatientState *ps,
                               float act_target, float hypoxia, uint8_t sleep,
                               Arrhythmia arrhythmia, float bp_offset, float dt) {
    PatientProfile *p = &ps->p;
    /* fixed draw count so behaviour stays reproducible/synchronised, like the Python z[8] */
    float z0 = rng_normal(&ps->rng); /* hr drift   */
    float z1 = rng_normal(&ps->rng); /* resp drift */
    float z2 = rng_normal(&ps->rng); /* bp drift   */
    float z3 = rng_normal(&ps->rng); /* temp drift */
    float z4 = rng_normal(&ps->rng); /* spo2 drift */
    float z5 = rng_normal(&ps->rng); /* afib hrv   */
    (void)rng_normal(&ps->rng);      /* z6 - reserved (matches 8-draw budget) */
    (void)rng_normal(&ps->rng);      /* z7 - reserved */

    act_target = clampf(act_target, 0.0f, 1.0f);
    hypoxia    = clampf(hypoxia, 0.0f, 1.0f);
    if (sleep) act_target = 0.0f;

    /* --- activity: quick response */
    ps->act = approach(ps->act, act_target, 4.0f, dt);

    /* --- fatigue: builds during sustained effort, decays slowly at rest */
    ps->fatigue_state = approach(ps->fatigue_state, ps->act * ps->act, 90.0f, dt);

    /* --- SpO2 */
    float spo2_target = p->spo2_base - 1.2f * ps->act - 14.0f * hypoxia;
    float tau_spo2 = (hypoxia > 0.0f) ? 8.0f : 15.0f;
    ps->spo2 = approach(ps->spo2, spo2_target, tau_spo2, dt);
    float spo2_true = clampf(ps->spo2 + ou_step(&ps->d_spo2, z4, dt), 60.0f, 100.0f);

    /* --- respiration */
    float resp_target = p->resp_base + 16.0f * powf(ps->act, 0.9f);
    float hypo_deficit = 95.0f - spo2_true;
    if (hypo_deficit > 0.0f) resp_target += 0.5f * hypo_deficit;
    if (sleep) resp_target -= 2.0f;
    ps->resp = approach(ps->resp, resp_target, 7.0f, dt);
    float resp_true = clampf(ps->resp + ou_step(&ps->d_resp, z1, dt), 6.0f, 45.0f);

    /* --- heart rate (deliberately non-linear) */
    float hyp_deficit = 95.0f - spo2_true;
    float hyp_drive = (hyp_deficit > 0.0f) ? p->hypox_sens * powf(hyp_deficit, 1.15f) : 0.0f;
    float hr_target = p->hr0
                     + p->act_sens * powf(ps->act, 0.8f)
                     + p->fatigue * 30.0f * ps->fatigue_state
                     + hyp_drive;
    if (sleep) hr_target -= 0.12f * p->hr0;
    switch (arrhythmia) {
        case ARR_TACHY: hr_target += 45.0f; break;
        case ARR_BRADY: hr_target -= 22.0f; break;
        case ARR_AFIB:  hr_target += 28.0f; break;
        default: break;
    }
    hr_target += ou_step(&ps->d_hr, z0, dt);
    float tau_hr = (hr_target > ps->hr) ? 5.0f : 11.0f; /* recovers slower than it rises */
    ps->hr = approach(ps->hr, hr_target, tau_hr, dt);
    float hr_true = clampf(ps->hr, 35.0f, 195.0f);

    /* --- HRV (RMSSD, ms) */
    float hrv_target = p->hrv0 * (1.0f - 0.6f * powf(ps->act, 0.8f));
    hrv_target *= 1.0f + 0.025f * (p->resp_base - resp_true);
    if (hyp_deficit > 0.0f) hrv_target *= 1.0f - 0.012f * hyp_deficit;
    if (sleep) hrv_target *= 1.25f;
    if (arrhythmia == ARR_AFIB) {
        hrv_target = 105.0f + 8.0f * z5;
    } else if (arrhythmia == ARR_TACHY) {
        hrv_target *= 0.6f;
    }
    ps->hrv = approach(ps->hrv, hrv_target, 8.0f, dt);
    float hrv_true = clampf(ps->hrv, 5.0f, 160.0f);

    /* --- blood pressure and temperature */
    float bp_target = p->bp_base + 30.0f * ps->act + bp_offset - (sleep ? 6.0f : 0.0f);
    ps->sbp = approach(ps->sbp, bp_target, 12.0f, dt);
    float bp_true = ps->sbp + ou_step(&ps->d_bp, z2, dt);

    float temp_target = p->temp_base + 0.5f * ps->act - (sleep ? 0.25f : 0.0f);
    ps->temp = approach(ps->temp, temp_target, 150.0f, dt);
    float temp_true = ps->temp + ou_step(&ps->d_temp, z3, dt);

    ps->t += dt;

    TruthFrame f;
    f.t = ps->t;
    f.hr = hr_true;
    f.rr = 60000.0f / hr_true;
    f.hrv = hrv_true;
    f.temp = temp_true;
    f.resp = resp_true;
    f.spo2 = spo2_true;
    f.bp = bp_true;
    f.activity = ps->act;
    f.arrhythmia = arrhythmia;
    f.hypoxia = hypoxia;
    f.sleep = sleep;
    return f;
}
