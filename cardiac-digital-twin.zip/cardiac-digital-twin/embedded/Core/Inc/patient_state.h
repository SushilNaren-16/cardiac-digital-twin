/*
 * patient_state.h - Physiology layer (embedded C port of Person B's patient_state.py)
 *
 * Coupling rules implemented (same as the Python version):
 *   activity  -> raises HR, respiration, BP, temperature (slowly), lowers HRV
 *   low SpO2  -> raises HR (compensation)
 *   respiration modulates HRV (slow breathing -> larger RSA)
 *   slow drift (Ornstein-Uhlenbeck) + random variation on every signal
 *
 * All floats (STM32F4/F7/H7 have a hardware FPU, so this runs fine at 1 Hz).
 */
#ifndef PATIENT_STATE_H
#define PATIENT_STATE_H

#include <stdint.h>
#include "rng.h"

typedef enum {
    ARR_NONE = 0,
    ARR_PVC,
    ARR_AFIB,
    ARR_TACHY,
    ARR_BRADY
} Arrhythmia;

typedef struct {
    const char *name;
    float hr0;         /* resting heart rate (bpm) */
    float hrv0;         /* resting HRV, RMSSD (ms) */
    float act_sens;      /* HR rise (bpm) at activity = 1 */
    float hypox_sens;     /* HR rise per SpO2 % below 95 (non-linear) */
    float spo2_base;      /* normal SpO2 (%) */
    float bp_base;       /* resting systolic BP (mmHg) */
    float resp_base;      /* resting breaths / min */
    float temp_base;      /* body temp (deg C) */
    float fatigue;       /* extra HR creep during sustained exertion */
    float noise;         /* multiplier on sensor noise */
    uint32_t seed;
} PatientProfile;

extern const PatientProfile PROFILE_ATHLETE;
extern const PatientProfile PROFILE_AVERAGE;
extern const PatientProfile PROFILE_ANXIOUS;

/* First-order lag: move x toward target with time constant tau (s) */
float approach(float x, float target, float tau, float dt);

typedef struct {
    float tau, sigma, x;
} OU;

void  ou_init(OU *o, float tau, float sigma);
float ou_step(OU *o, float z, float dt);

/* The hidden TRUE patient state for one instant */
typedef struct {
    float t;
    float hr, rr, hrv, temp, resp, spo2, bp, activity;
    Arrhythmia arrhythmia;
    float hypoxia;
    uint8_t sleep;
} TruthFrame;

typedef struct {
    PatientProfile p;
    Rng   rng;
    float t;
    float act, resp, spo2, hr, sbp, temp, fatigue_state, hrv;
    OU d_hr, d_resp, d_bp, d_temp, d_spo2;
} PatientState;

void patient_state_init(PatientState *ps, PatientProfile profile);

/* Advance one second (dt seconds). Mirrors PatientState.step() in Python. */
TruthFrame patient_state_step(PatientState *ps,
                               float act_target, float hypoxia, uint8_t sleep,
                               Arrhythmia arrhythmia, float bp_offset, float dt);

#endif /* PATIENT_STATE_H */
