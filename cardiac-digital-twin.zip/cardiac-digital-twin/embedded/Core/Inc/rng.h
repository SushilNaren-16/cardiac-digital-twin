/*
 * rng.h - tiny deterministic PRNG for embedded use (replaces numpy.random)
 *
 * xorshift32 for uniform floats, Box-Muller for standard-normal floats.
 * Deterministic from a seed, same as np.random.default_rng(seed) conceptually
 * (not bit-identical to numpy, but same statistical behaviour).
 */
#ifndef RNG_H
#define RNG_H

#include <stdint.h>

typedef struct {
    uint32_t state;
    uint8_t  has_spare;
    float    spare;
} Rng;

void  rng_seed(Rng *r, uint32_t seed);
float rng_uniform(Rng *r);          /* [0, 1) */
float rng_uniform_range(Rng *r, float lo, float hi);
float rng_normal(Rng *r);           /* mean 0, std 1 */
int   rng_poisson(Rng *r, float lambda);
int   rng_int_range(Rng *r, int lo, int hi_exclusive);

#endif /* RNG_H */
