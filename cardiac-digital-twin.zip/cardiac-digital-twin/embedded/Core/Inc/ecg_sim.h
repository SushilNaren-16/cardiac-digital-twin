/*
 * ecg_sim.h - ECG generator (embedded C port of Person B's ecg_sim.py)
 *
 * Generates ECG (mV) at fs = 250 Hz, one 1-second chunk at a time, so HR/HRV/
 * respiration can change LIVE. Beat morphology = sum of Gaussians (P,Q,R,S,T).
 *
 * IMPORTANT for STM32: this only evaluates Gaussians for beats that fall near
 * the current 1-second window (a small fixed-size pending-beat buffer), so the
 * per-second cost is a few hundred float ops -- trivial for an FPU at 1 Hz.
 */
#ifndef ECG_SIM_H
#define ECG_SIM_H

#include <stdint.h>
#include "rng.h"
#include "patient_state.h"

#define ECG_FS              250      /* samples/sec - matches a typical AD8232+STM32 ADC setup */
#define ECG_SAMPLES_PER_SEC ECG_FS
#define ECG_MAX_PENDING_BEATS 8
#define ECG_MAX_NEW_BEATS     6      /* generous upper bound on beats landing in 1 s */

typedef struct {
    float t_ms;
    float rr_ms;
    Arrhythmia kind;
} EcgBeat;

typedef struct {
    float t;      /* scheduled R-peak time (s), absolute */
    float rr;     /* rr interval (ms) leading to this beat */
    Arrhythmia kind;
    uint8_t used;
} PendingBeat;

typedef struct {
    int fs;
    Rng rng;
    float noise;
    float mains_hz;
    float t;                 /* time rendered so far (s) */
    float next_r;            /* time of next R peak (s) */
    PendingBeat beats[ECG_MAX_PENDING_BEATS];
    float rsa_phase;
    uint8_t forced_rr_valid;
    float forced_rr;
    float resp_phase;
    float motion_zi;         /* single-pole filter state for motion artifact */
    float last_rr;
} EcgSynth;

void ecg_synth_init(EcgSynth *e, int fs, uint32_t seed, float noise, float mains_hz);

/*
 * Advance the ECG by 1 second.
 * out_ecg   : caller-provided buffer of length ECG_SAMPLES_PER_SEC (mV)
 * out_beats : caller-provided buffer of length >= ECG_MAX_NEW_BEATS
 * returns the number of beats written to out_beats
 */
int ecg_synth_render_1s(EcgSynth *e, float hr, float hrv, float resp,
                         Arrhythmia rhythm, float activity, uint8_t lead_off,
                         float *out_ecg, EcgBeat *out_beats);

/* Convert mV -> STM32 ADC counts the way an AD8232 module would present it
 * (only needed if you DAC-replay the generated waveform into an analog front end) */
uint16_t ecg_to_adc_counts(float ecg_mv, int bits, float gain, float vref);

#endif /* ECG_SIM_H */
