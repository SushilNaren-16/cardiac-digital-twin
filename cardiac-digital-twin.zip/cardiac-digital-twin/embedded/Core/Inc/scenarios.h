/*
 * scenarios.h - Scenario engine + one-call API (embedded C port of scenarios.py)
 *
 *   Simulator sim;
 *   simulator_init(&sim, PROFILE_AVERAGE, demo_3min());
 *   Frame f = simulator_get_frame(&sim);   // advances 1 second
 *
 * Frame holds the SHARED DICT fields (t, hr, rr, hrv, temp, resp, spo2, bp,
 * activity, leads_ok, source) plus ecg[250] + beats[] for that second.
 *
 * D's what-if sliders call simulator_set_* / simulator_clear_* to override the
 * scripted timeline live (e.g. from parsed UART commands sent by D's laptop).
 */
#ifndef SCENARIOS_H
#define SCENARIOS_H

#include <stdint.h>
#include "patient_state.h"
#include "ecg_sim.h"

#define TIMELINE_MAX_SEGMENTS 16
#define RR_HIST_LEN 30

typedef struct {
    float start, end;
    const char *label;
    float activity;
    float hypoxia;
    uint8_t sleep;
    Arrhythmia arrhythmia;
    uint8_t lead_off;
    float bp_offset;
} Segment;

typedef struct {
    const char *name;
    Segment segments[TIMELINE_MAX_SEGMENTS];
    int count;
    float duration;
} Timeline;

void timeline_init(Timeline *tl, const char *name);
/* Appends a segment of `seconds` length; unspecified fields default to 0/NONE. */
void timeline_add(Timeline *tl, const char *label, float seconds,
                   float activity, float hypoxia, uint8_t sleep,
                   Arrhythmia arrhythmia, uint8_t lead_off, float bp_offset);
const Segment *timeline_at(const Timeline *tl, float t);

/* ---- ready-made scripts (mirrors demo_5min()/demo_3min() in scenarios.py) ---- */
Timeline demo_3min(void);
Timeline demo_5min(void);
Timeline sleep_demo(void);

/* ---- live override state (D's sliders) ---- */
typedef struct {
    uint8_t activity_set;   float activity;
    uint8_t hypoxia_set;    float hypoxia;
    uint8_t arrhythmia_set; Arrhythmia arrhythmia;
    uint8_t sleep_set;      uint8_t sleep;
    uint8_t lead_off_set;   uint8_t lead_off;
    uint8_t bp_offset_set;  float bp_offset;
    uint8_t any_set;        /* true if at least one override is active */
} Overrides;

typedef struct {
    float t, hr, rr, hrv, temp, resp, spo2, bp, activity;
    uint8_t leads_ok;
    const char *source;
    const char *label;          /* current scenario label, "+live" suffix implied by caller if needed */
    float ecg[ECG_SAMPLES_PER_SEC];
    EcgBeat beats[ECG_MAX_NEW_BEATS];
    int beat_count;
} Frame;

typedef struct {
    PatientProfile profile;
    Timeline timeline;
    PatientState state;
    PatientState shadow;        /* same patient/noise, no anomalies -> residual scoring */
    uint8_t shadow_enabled;
    EcgSynth ecg;
    Rng rng;
    Overrides overrides;
    float rr_hist[RR_HIST_LEN];
    int rr_hist_count, rr_hist_head;
    float last_hr, last_rr, last_hrv;
    float t;
    const char *source;
} Simulator;

void simulator_init(Simulator *sim, PatientProfile profile, Timeline timeline,
                     int shadow_enabled, const char *source);

/* live controls -- call these from your UART command parser */
void simulator_set_activity(Simulator *sim, float activity);
void simulator_inject_hypoxia(Simulator *sim, float severity);
void simulator_clear_hypoxia(Simulator *sim);
void simulator_set_spo2_target(Simulator *sim, float spo2_pct); /* converts to coherent hypoxia */
void simulator_set_arrhythmia(Simulator *sim, Arrhythmia kind);
void simulator_clear_arrhythmia(Simulator *sim);
void simulator_set_sleep(Simulator *sim, uint8_t sleep);
void simulator_set_lead_off(Simulator *sim, uint8_t on);
void simulator_set_bp_offset(Simulator *sim, float mmhg);
void simulator_clear_overrides(Simulator *sim); /* back to the scripted timeline */

/* Advance 1 second. Returns the shared-dict frame + ecg + beats. */
Frame simulator_get_frame(Simulator *sim);

/* STM32-style per-heartbeat line for D's replay mode / UART streaming:
 * "B,<t_ms>,<rr_ms>,<hr_bpm>,<hrv_ms>,<temp_c>,<leads_ok>"
 * Writes into caller's buf (size >= 64), returns length written. */
int simulator_beat_line(const Frame *f, float temp, char *buf, int buf_size,
                         const EcgBeat *b);

#endif /* SCENARIOS_H */
