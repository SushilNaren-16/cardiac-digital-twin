/*
 * corrupt.h - Corruption injector (embedded C port of corrupt.py, Phase 3)
 *
 * Frame-level corruption only (drop/spike/stale per vital field). The full
 * sample-level ECG corruption in the Python version is meant to run on the
 * HOST/laptop side against logged CSVs -- it's not something the STM32 needs
 * to do to its own live signal. If you need it for a fusion-layer demo,
 * run corrupt.py on the laptop against the CSVs this firmware logs.
 */
#ifndef CORRUPT_H
#define CORRUPT_H

#include <stdint.h>
#include "rng.h"
#include "scenarios.h"

typedef struct {
    float level;     /* 0.0 .. 0.5, fraction of data damaged/lost */
    Rng rng;
    float stale_hr, stale_rr, stale_hrv, stale_temp, stale_resp, stale_spo2, stale_bp, stale_activity;
    uint8_t have_stale;
} Corruptor;

void corruptor_init(Corruptor *c, float level, uint32_t seed);

/* Corrupts a COPY of the frame's vital fields in place on `out` (pass a copy of
 * the clean Frame in). validity flags tell the caller which fields were dropped. */
typedef struct {
    uint8_t hr_valid, rr_valid, hrv_valid, temp_valid, resp_valid, spo2_valid, bp_valid, activity_valid;
} CorruptValidity;

void corruptor_apply(Corruptor *c, Frame *f, CorruptValidity *valid_out);

#endif /* CORRUPT_H */
