# cardiac-digital-twin

Synthetic patient: hidden true physiology → ECG → measured vitals, plus a
scenario engine, a sensor-corruption injector, and a matching STM32 port.

```
cardiac-digital-twin/
├── simulator/     Python reference implementation (numpy/scipy/pandas)
├── data/          Pre-generated datasets for the fusion/twin-learning team
└── embedded/      Pure-C port that runs directly on an STM32 microcontroller
```

## simulator/ (Python, host/laptop side)

```
pip install numpy scipy pandas
python -m simulator.test_simulator     # smoke test (should print ALL PASSED)
python -m simulator.generate_datasets  # rebuild data/*.csv
```

```python
from simulator import Simulator, demo_5min, demo_3min
sim = Simulator("average", demo_3min())
frame = sim.get_frame()   # advances 1 second
```

See `simulator/README.md` for the full API (live what-if sliders, arrhythmias,
corruption levels, the shared-dict contract, etc.).

## embedded/ (C, runs on the STM32 itself)

A from-scratch C99 port of the same algorithms — physiology (first-order lag +
Ornstein-Uhlenbeck drift), ECG synthesis (RR/RSA + Gaussian-sum PQRST beats),
the scenario/timeline engine, and the corruption injector — with no numpy,
no scipy, no dynamic memory. Compiles and runs correctly with plain `gcc` on
a laptop for testing, and drops straight into an STM32CubeIDE project since it
only needs `<math.h>` and a hardware FPU.

```
cd embedded/Core
gcc -DTWIN_APP_HOST_TEST -IInc Src/*.c -lm -O2 -o twin_test && ./twin_test
```

See `embedded/README.md` for how to wire it into a real STM32CubeIDE project
(UART output, the live-control command parser for the what-if sliders, etc.).

## data/

Pre-generated CSVs (`*_train.csv`, `*_demo.csv`, `*_demo_truth.csv`, and
corrupted variants) for the team building/scoring the learned digital twin,
produced by `simulator/generate_datasets.py`.
