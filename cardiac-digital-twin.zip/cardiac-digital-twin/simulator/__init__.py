"""Person B: synthetic patient simulator (physiology, ECG, scenarios, corruption)."""
from .patient_state import PatientProfile, PatientState, PROFILES, random_profile
from .ecg_sim import ECGSynth, to_adc_counts
from .scenarios import (Simulator, Timeline, Segment, demo_5min, demo_3min,
                        sleep_demo, training_random, SHARED_KEYS)
