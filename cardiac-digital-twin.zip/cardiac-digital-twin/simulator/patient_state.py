"""
patient_state.py  -  Physiology layer (Person B)

The HIDDEN "true" patient. It owns the real physiological state; everything
the twin sees is a noisy measurement of it (see scenarios.Simulator).

Coupling rules implemented
  * activity  -> raises HR, respiration, BP, temperature (slowly), lowers HRV
  * low SpO2  -> raises HR (compensation)
  * respiration modulates HRV (slow breathing -> larger respiratory sinus arrhythmia)
  * slow drift (Ornstein-Uhlenbeck) + random variation on every signal

IMPORTANT (circular-validation guard):
  The equations below are deliberately NOT simple linear regressions:
  concave activity response, non-linear hypoxia response, fatigue creep,
  asymmetric lag (HR recovers slower than it rises), per-patient parameters.
  Person C's twin should learn these from data, not copy them.
"""
from dataclasses import dataclass
import numpy as np


# --------------------------------------------------------------------------
# Per-patient parameters (what makes each patient different)
# --------------------------------------------------------------------------
@dataclass
class PatientProfile:
    name: str = "average"
    hr0: float = 70.0          # resting heart rate (bpm)
    hrv0: float = 50.0         # resting HRV, RMSSD (ms)
    act_sens: float = 50.0     # HR rise (bpm) at activity = 1
    hypox_sens: float = 1.6    # HR rise (bpm) per SpO2 % below 95 (scaled, non-linear)
    spo2_base: float = 98.0    # normal SpO2 (%)
    bp_base: float = 120.0     # resting systolic BP (mmHg)
    resp_base: float = 14.0    # resting breaths / min
    temp_base: float = 36.7    # body temp (deg C)
    fatigue: float = 0.15      # extra HR creep during sustained exertion
    noise: float = 1.0         # multiplier on sensor noise
    seed: int = 0


PROFILES = {
    "athlete": PatientProfile("athlete", hr0=55, hrv0=70, act_sens=35, hypox_sens=1.2,
                              spo2_base=99, bp_base=110, resp_base=12, temp_base=36.5,
                              fatigue=0.08, seed=1),
    "average": PatientProfile("average", hr0=70, hrv0=50, act_sens=50, hypox_sens=1.6,
                              spo2_base=98, bp_base=120, resp_base=14, temp_base=36.7,
                              fatigue=0.15, seed=2),
    "anxious": PatientProfile("anxious", hr0=82, hrv0=25, act_sens=55, hypox_sens=2.0,
                              spo2_base=97, bp_base=135, resp_base=16, temp_base=36.9,
                              fatigue=0.22, seed=3),
}


def random_profile(seed: int, name=None) -> PatientProfile:
    """A new synthetic patient with plausible, randomly different parameters."""
    r = np.random.default_rng(1000 + seed)
    return PatientProfile(
        name=name or f"patient_{seed:02d}",
        hr0=float(r.uniform(56, 86)), hrv0=float(r.uniform(22, 72)),
        act_sens=float(r.uniform(32, 60)), hypox_sens=float(r.uniform(1.1, 2.2)),
        spo2_base=float(r.uniform(96.5, 99)), bp_base=float(r.uniform(106, 136)),
        resp_base=float(r.uniform(12, 17)), temp_base=float(r.uniform(36.4, 37.0)),
        fatigue=float(r.uniform(0.06, 0.25)), seed=seed)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def approach(x, target, tau, dt=1.0):
    """First-order lag: move x toward target with time constant tau (s)."""
    return x + (target - x) * (1.0 - np.exp(-dt / tau))


class OU:
    """Slow mean-reverting random drift (Ornstein-Uhlenbeck)."""

    def __init__(self, tau, sigma):
        self.tau, self.sigma, self.x = tau, sigma, 0.0

    def step(self, z, dt=1.0):
        self.x += -self.x / self.tau * dt + self.sigma * np.sqrt(dt) * z
        return self.x


ARRHYTHMIAS = (None, "pvc", "afib", "tachy", "brady")


# --------------------------------------------------------------------------
# The hidden patient
# --------------------------------------------------------------------------
class PatientState:
    """Advance with step(); returns the TRUE state dict for that second.

    step() always draws the same number of random numbers, so two patients
    created with the same seed stay noise-synchronised (used for the
    'shadow' patient that shows what HR would have been without an anomaly).
    """

    def __init__(self, profile: PatientProfile):
        self.p = profile
        self.rng = np.random.default_rng(profile.seed)
        self.t = 0.0
        self.act = 0.0
        self.resp = profile.resp_base
        self.spo2 = profile.spo2_base
        self.hr = profile.hr0
        self.sbp = profile.bp_base
        self.temp = profile.temp_base
        self.fatigue_state = 0.0
        self.hrv = profile.hrv0
        self.d_hr = OU(tau=90, sigma=0.6)      # slow HR drift (bpm)
        self.d_resp = OU(tau=60, sigma=0.15)
        self.d_bp = OU(tau=120, sigma=0.5)
        self.d_temp = OU(tau=300, sigma=0.01)
        self.d_spo2 = OU(tau=60, sigma=0.08)

    # ------------------------------------------------------------------
    def step(self, act_target=0.0, hypoxia=0.0, sleep=False, arrhythmia=None,
             bp_offset=0.0, dt=1.0):
        """
        act_target : 0..1   (0 rest, ~0.5 walking, 1 running)
        hypoxia    : 0..1   severity, 1 -> SpO2 target ~ 14 points below baseline
        sleep      : bool
        arrhythmia : None | 'pvc' | 'afib' | 'tachy' | 'brady'
        bp_offset  : mmHg added to the BP target (what-if hypertension / hypotension)
        """
        p = self.p
        z = self.rng.standard_normal(8)          # fixed draw count (shadow-safe)
        act_target = float(np.clip(act_target, 0, 1))
        hypoxia = float(np.clip(hypoxia, 0, 1))
        if sleep:
            act_target = 0.0

        # --- activity (the person's effort), quick response
        self.act = approach(self.act, act_target, 4.0, dt)

        # --- fatigue: builds during sustained effort, decays slowly at rest
        self.fatigue_state = approach(self.fatigue_state, self.act ** 2, 90.0, dt)

        # --- SpO2: falls toward hypoxic target, mild dip with hard exertion
        spo2_target = p.spo2_base - 1.2 * self.act - 14.0 * hypoxia
        tau = 8.0 if hypoxia > 0 else 15.0
        self.spo2 = approach(self.spo2, spo2_target, tau, dt)
        spo2_true = float(np.clip(self.spo2 + self.d_spo2.step(z[4], dt), 60, 100))

        # --- respiration: exertion, hypoxic drive, sleep slows it
        resp_target = p.resp_base + 16.0 * self.act ** 0.9
        resp_target += 0.5 * max(0.0, 95.0 - spo2_true)          # hypoxic ventilatory drive
        if sleep:
            resp_target -= 2.0
        self.resp = approach(self.resp, resp_target, 7.0, dt)
        resp_true = float(np.clip(self.resp + self.d_resp.step(z[1], dt), 6, 45))

        # --- heart rate (non-linear on purpose)
        hyp_drive = p.hypox_sens * (max(0.0, 95.0 - spo2_true) ** 1.15)
        hr_target = (p.hr0
                     + p.act_sens * self.act ** 0.8              # concave activity response
                     + p.fatigue * 30.0 * self.fatigue_state     # exertion creep
                     + hyp_drive)
        if sleep:
            hr_target -= 0.12 * p.hr0
        if arrhythmia == "tachy":
            hr_target += 45
        elif arrhythmia == "brady":
            hr_target -= 22
        elif arrhythmia == "afib":
            hr_target += 28
        hr_target += self.d_hr.step(z[0], dt)
        tau_hr = 5.0 if hr_target > self.hr else 11.0             # recovers slower than it rises
        self.hr = approach(self.hr, hr_target, tau_hr, dt)
        hr_true = float(np.clip(self.hr, 35, 195))

        # --- HRV (RMSSD, ms): exertion lowers it, slow breathing raises it (RSA)
        hrv_target = p.hrv0 * (1.0 - 0.6 * self.act ** 0.8)
        hrv_target *= 1.0 + 0.025 * (p.resp_base - resp_true)
        hrv_target *= 1.0 - 0.012 * max(0.0, 95.0 - spo2_true)
        if sleep:
            hrv_target *= 1.25
        if arrhythmia == "afib":
            hrv_target = 105.0 + 8 * z[5]
        elif arrhythmia == "tachy":
            hrv_target *= 0.6
        self.hrv = approach(self.hrv, hrv_target, 8.0, dt)
        hrv_true = float(np.clip(self.hrv, 5, 160))

        # --- blood pressure (systolic) and temperature
        bp_target = p.bp_base + 30.0 * self.act + bp_offset - (6.0 if sleep else 0.0)
        self.sbp = approach(self.sbp, bp_target, 12.0, dt)
        bp_true = float(self.sbp + self.d_bp.step(z[2], dt))
        temp_target = p.temp_base + 0.5 * self.act - (0.25 if sleep else 0.0)
        self.temp = approach(self.temp, temp_target, 150.0, dt)
        temp_true = float(self.temp + self.d_temp.step(z[3], dt))

        self.t += dt
        return dict(t=self.t, hr=hr_true, rr=60000.0 / hr_true, hrv=hrv_true,
                    temp=temp_true, resp=resp_true, spo2=spo2_true, bp=bp_true,
                    activity=float(self.act), arrhythmia=arrhythmia or "none",
                    hypoxia=hypoxia, sleep=bool(sleep))
