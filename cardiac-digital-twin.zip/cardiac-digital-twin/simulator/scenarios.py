"""
scenarios.py  -  Scenario engine + the one-call API (Person B)

    from simulator.scenarios import Simulator, demo_5min

    sim = Simulator("average", demo_5min())
    frame = sim.get_frame()          # advances 1 second, returns coherent vitals + ECG

The frame is the SHARED DICT from docs/protocol.md:
    t (s), hr (bpm), rr (ms), hrv (ms, RMSSD), temp (C), resp (/min), spo2 (%),
    bp (mmHg systolic), activity (0..1), leads_ok (bool), source ("simulated")
plus two EXTRA keys (ignore them if you only need the shared dict):
    ecg   : numpy array, 250 samples (1 s of ECG in mV at 250 Hz)
    beats : list of {t_ms, rr_ms, kind} R-peaks that occurred in this second

What the twin sees = MEASURED values (noisy, computed from the generated ECG beats).
What is scored     = TRUE values, kept in sim.truth_log / sim.save_truth().

Live controls for D's what-if sliders (they override the scripted timeline):
    sim.set_state(activity=0.7, spo2=88, arrhythmia="pvc", bp_offset=25, sleep=False)
    sim.inject_hypoxia(0.9);  sim.clear_hypoxia()
    sim.set_arrhythmia("afib"); sim.clear_arrhythmia()
    sim.set_lead_off(True)
    sim.clear_overrides()            # back to the scripted timeline
"""
from collections import deque
from dataclasses import dataclass
import numpy as np
import pandas as pd

from .patient_state import PatientState, PatientProfile, PROFILES, ARRHYTHMIAS
from .ecg_sim import ECGSynth

SHARED_KEYS = ["t", "hr", "rr", "hrv", "temp", "resp", "spo2", "bp",
               "activity", "leads_ok", "source"]


# ==========================================================================
# Timeline
# ==========================================================================
@dataclass
class Segment:
    start: float
    end: float
    label: str
    activity: float = 0.0          # 0 rest, 0.5 walking, 1 running
    hypoxia: float = 0.0           # severity 0..1
    sleep: bool = False
    arrhythmia: str = None         # None | pvc | afib | tachy | brady
    lead_off: bool = False
    bp_offset: float = 0.0


class Timeline:
    """Ordered list of segments. Build with .add(label, seconds, **params)."""

    def __init__(self, name="custom"):
        self.name, self.segments, self._t = name, [], 0.0

    def add(self, label, seconds, **params):
        self.segments.append(Segment(self._t, self._t + seconds, label, **params))
        self._t += seconds
        return self

    @property
    def duration(self):
        return self._t

    def at(self, t):
        for s in self.segments:
            if s.start <= t < s.end:
                return s
        return Segment(t, t + 1, "rest")            # after the script ends: rest

    def table(self):
        return [(s.start, s.end, s.label) for s in self.segments]


# ---- ready-made scripts --------------------------------------------------
def demo_5min():
    """Full 5-minute script used for datasets and the 'done when' check."""
    return (Timeline("demo_5min")
            .add("rest", 60)
            .add("walking", 60, activity=0.5)
            .add("recovery", 30)
            .add("hypoxia", 60, hypoxia=0.9)
            .add("recovery", 30)
            .add("pvc", 30, arrhythmia="pvc")
            .add("afib", 20, arrhythmia="afib")
            .add("recovery", 10))


def demo_3min():
    """The 3-minute LIVE DEMO script (matches the pitch: rest -> walk -> hypoxia).
    Timings are exact so D can rehearse against them:
      0:00-0:45 rest | 0:45-1:30 walking | 1:30-1:45 recovery
      1:45-2:30 hypoxia | 2:30-3:00 recovery
    """
    return (Timeline("demo_3min")
            .add("rest", 45)
            .add("walking", 45, activity=0.5)
            .add("recovery", 15)
            .add("hypoxia", 45, hypoxia=0.9)
            .add("recovery", 30))


def sleep_demo():
    return (Timeline("sleep_demo").add("rest", 60).add("sleep", 180, sleep=True)
            .add("waking", 60))


def training_random(minutes=20, seed=0):
    """Healthy data ONLY (no anomalies) with varied activity - for fitting the twin."""
    r = np.random.default_rng(seed)
    tl, total = Timeline(f"train_{seed}"), 0.0
    levels = [0.0, 0.0, 0.15, 0.3, 0.5, 0.7, 0.9]
    while total < minutes * 60:
        d = float(r.integers(25, 70))
        if r.random() < 0.10:
            tl.add("train_sleep", d, sleep=True)
        else:
            tl.add("train", d, activity=float(r.choice(levels)))
        total += d
    return tl


# ==========================================================================
# Simulator
# ==========================================================================
class Simulator:
    def __init__(self, profile="average", timeline=None, fs=250, noise=1.0,
                 source="simulated", shadow=True, seed=None):
        if isinstance(profile, str):
            profile = PROFILES[profile]
        if seed is not None:
            profile = PatientProfile(**{**profile.__dict__, "seed": seed})
        self.profile, self.fs, self.source = profile, fs, source
        self.timeline = timeline or demo_5min()
        self.state = PatientState(profile)
        # 'shadow' = same patient, same random noise, but NO hypoxia/arrhythmia.
        # Lets C score residual alerts against the true "what HR should have been".
        self.shadow = PatientState(profile) if shadow else None
        self.ecg = ECGSynth(fs=fs, seed=profile.seed, noise=noise * profile.noise)
        self.rng = np.random.default_rng(profile.seed + 777)
        self.overrides = {}
        self.truth_log = []
        self._rr_hist = deque(maxlen=30)
        self._last_meas = dict(hr=profile.hr0, rr=60000 / profile.hr0, hrv=profile.hrv0)
        self.t = 0.0

    # ---------------------------------------------------------------- live controls
    def set_state(self, activity=None, spo2=None, hypoxia=None, arrhythmia="__keep__",
                  sleep=None, lead_off=None, bp_offset=None):
        """What-if controls (D's sliders call this). Any arg left as None is unchanged.
        spo2: target SpO2 (%) -> converted to a hypoxia severity so the physiology stays coherent.
        arrhythmia: None/'none' clears it, or one of pvc | afib | tachy | brady."""
        o = self.overrides
        if activity is not None:
            o["activity"] = float(np.clip(activity, 0, 1))
        if hypoxia is not None:
            o["hypoxia"] = float(np.clip(hypoxia, 0, 1))
        if spo2 is not None:
            act = o.get("activity", self.timeline.at(self.t).activity)
            sev = (self.profile.spo2_base - 1.2 * act - float(spo2)) / 14.0
            o["hypoxia"] = float(np.clip(sev, 0, 1))
        if arrhythmia != "__keep__":
            a = None if arrhythmia in (None, "none") else arrhythmia
            if a not in ARRHYTHMIAS:
                raise ValueError(f"arrhythmia must be one of {ARRHYTHMIAS}")
            o["arrhythmia"] = a
        if sleep is not None:
            o["sleep"] = bool(sleep)
        if lead_off is not None:
            o["lead_off"] = bool(lead_off)
        if bp_offset is not None:
            o["bp_offset"] = float(bp_offset)

    def set_activity(self, x): self.set_state(activity=x)
    def inject_hypoxia(self, severity=0.9): self.set_state(hypoxia=severity)
    def clear_hypoxia(self): self.set_state(hypoxia=0.0)
    def set_arrhythmia(self, kind): self.set_state(arrhythmia=kind)
    def clear_arrhythmia(self): self.set_state(arrhythmia=None)
    def set_lead_off(self, on=True): self.set_state(lead_off=on)

    def clear_overrides(self, *names):
        """No args = back to the scripted timeline. Or clear only e.g. 'hypoxia'."""
        if names:
            for n in names:
                self.overrides.pop(n, None)
        else:
            self.overrides.clear()

    def _current_inputs(self):
        seg = self.timeline.at(self.t)
        p = dict(activity=seg.activity, hypoxia=seg.hypoxia, sleep=seg.sleep,
                 arrhythmia=seg.arrhythmia, lead_off=seg.lead_off,
                 bp_offset=seg.bp_offset)
        label = seg.label
        p.update(self.overrides)
        if self.overrides:
            label = label + "+live"
        return p, label

    # ---------------------------------------------------------------- main call
    def get_frame(self, with_truth=False, with_ecg=True):
        """Advance 1 second. Returns the shared dict (+ ecg, beats)."""
        p, label = self._current_inputs()
        truth = self.state.step(p["activity"], p["hypoxia"], p["sleep"],
                                p["arrhythmia"], p["bp_offset"])
        normal = None
        if self.shadow is not None:
            normal = self.shadow.step(p["activity"], 0.0, p["sleep"], None, p["bp_offset"])

        # ECG for this second, driven by the TRUE state
        ecg, beats = self.ecg.render(1.0, truth["hr"], truth["hrv"], truth["resp"],
                                     p["arrhythmia"], truth["activity"], p["lead_off"])
        if p["lead_off"]:
            beats = []                       # electrode off: the detector sees no beats
        for b in beats:
            self._rr_hist.append(b["rr_ms"])

        # ---- what an STM32 would MEASURE from that ECG
        if p["lead_off"] or len(self._rr_hist) < 3:
            meas = dict(self._last_meas) if p["lead_off"] else dict(
                hr=truth["hr"], rr=truth["rr"], hrv=truth["hrv"])
        else:
            rr = np.array(self._rr_hist)
            rr_mean = float(rr[-5:].mean())
            meas = dict(hr=60000.0 / rr_mean, rr=rr_mean,
                        hrv=float(np.sqrt(np.mean(np.diff(rr) ** 2))))
        if not p["lead_off"]:
            self._last_meas = meas

        n = self.profile.noise
        r = self.rng
        frame = dict(
            t=truth["t"], hr=round(meas["hr"], 1), rr=round(meas["rr"], 1),
            hrv=round(meas["hrv"], 1),
            temp=round(truth["temp"] + r.normal(0, 0.03 * n), 2),
            resp=round(truth["resp"] + r.normal(0, 0.5 * n), 1),
            spo2=round(float(np.clip(truth["spo2"] + r.normal(0, 0.4 * n), 0, 100)), 1),
            bp=round(truth["bp"] + r.normal(0, 2.0 * n), 1),
            activity=round(float(np.clip(truth["activity"] + r.normal(0, 0.02 * n), 0, 1)), 3),
            leads_ok=not p["lead_off"], source=self.source)

        # ---- ground-truth log (for scoring the twin)
        rec = dict(truth)
        rec.update(label=label, lead_off=p["lead_off"],
                   anomaly=int(truth["hypoxia"] > 0.05 or truth["arrhythmia"] != "none"))
        if normal is not None:
            rec.update(hr_normal=normal["hr"], hrv_normal=normal["hrv"],
                       spo2_normal=normal["spo2"], resp_normal=normal["resp"],
                       hr_residual_true=truth["hr"] - normal["hr"])
        self.truth_log.append(rec)

        self.t = truth["t"]
        if with_ecg:
            frame["ecg"], frame["beats"] = ecg, beats
        if with_truth:
            frame["truth"] = rec
        return frame

    # ---------------------------------------------------------------- helpers
    def run(self, seconds=None, **kw):
        """Generator of frames until the timeline (or `seconds`) is done."""
        n = int(seconds if seconds is not None else self.timeline.duration)
        for _ in range(n):
            yield self.get_frame(**kw)

    def collect(self, seconds=None, keep_ecg=False):
        """Run and return (measured_df, truth_df, ecg_array_or_None)."""
        rows, ecgs = [], []
        for f in self.run(seconds, with_ecg=True):
            ecgs.append(f["ecg"])
            rows.append({k: f[k] for k in SHARED_KEYS})
        return (pd.DataFrame(rows), pd.DataFrame(self.truth_log),
                np.concatenate(ecgs) if keep_ecg else None)

    def truth_df(self):
        return pd.DataFrame(self.truth_log)

    def save_truth(self, path):
        self.truth_df().round(3).to_csv(path, index=False)
        return path

    @staticmethod
    def b_lines(frame):
        """STM32-style per-heartbeat lines for D's replay mode (docs/protocol.md):
        B,<t_ms>,<rr_ms>,<hr_bpm>,<hrv_ms>,<temp_c>,<leads_ok>"""
        return [f"B,{int(b['t_ms'])},{int(round(b['rr_ms']))},{frame['hr']:.0f},"
                f"{frame['hrv']:.0f},{frame['temp']:.1f},{int(frame['leads_ok'])}"
                for b in frame.get("beats", [])]
