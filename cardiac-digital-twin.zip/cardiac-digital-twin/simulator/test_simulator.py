"""Smoke test for Person B's deliverables.   Run from repo root:  python -m simulator.test_simulator"""
import numpy as np
from scipy.signal import find_peaks
from simulator import Simulator, demo_5min, demo_3min, SHARED_KEYS
from simulator.corrupt import Corruptor


def test_get_frame_5_minutes():
    sim = Simulator("average", demo_5min())
    frames = [sim.get_frame() for _ in range(300)]
    assert all(k in frames[0] for k in SHARED_KEYS)
    assert all(len(f["ecg"]) == 250 for f in frames)                 # 1 s @ 250 Hz
    truth = sim.truth_df()
    hr_err = np.mean(np.abs(np.array([f["hr"] for f in frames]) - truth.hr.values))
    assert hr_err < 3.0, hr_err                                      # measured HR tracks true HR
    ecg = np.concatenate([f["ecg"] for f in frames])
    pk, _ = find_peaks(ecg, height=0.55, distance=int(0.25 * 250))
    n_beats = sum(len(f["beats"]) for f in frames)
    assert abs(len(pk) - n_beats) <= 3, (len(pk), n_beats)          # ECG waveform agrees with beat schedule
    walk, rest = truth[truth.label == "walking"].hr.mean(), truth[truth.label == "rest"].hr.mean()
    assert walk > rest + 20                                          # activity raises HR
    hyp = truth[truth.label == "hypoxia"]
    assert hyp.spo2.min() < 90 and (hyp.hr_residual_true.mean() > 10)  # hypoxia: SpO2 down, HR up vs normal
    print("ok  5-minute get_frame(): HR MAE %.2f bpm, %d beats" % (hr_err, n_beats))


def test_live_controls():
    sim = Simulator("average", demo_3min())
    for _ in range(10): sim.get_frame()
    sim.set_state(spo2=86, arrhythmia="pvc")
    for _ in range(40): f = sim.get_frame(with_truth=True)
    assert f["truth"]["anomaly"] == 1 and f["spo2"] < 92 and "+live" in f["truth"]["label"]
    sim.clear_overrides()
    assert not sim.overrides
    sim.set_lead_off(True); f = sim.get_frame()
    assert f["leads_ok"] is False and f["beats"] == []
    print("ok  live controls")


def test_corruption_levels():
    sim = Simulator("average", demo_5min()); meas, truth, ecg = sim.collect(keep_ecg=True)
    for lv in (0.0, 0.25, 0.5):
        c = Corruptor(lv, seed=1).ecg_corrupt(ecg)
        lost = 1 - c["valid"].mean(); off = 1 - c["leads_ok"].mean()
        assert abs(lost + off - lv) < 0.03, (lv, lost, off)
        assert np.array_equal(c["clean"], ecg)                       # ground truth untouched
    print("ok  corruption levels 0 / 0.25 / 0.5")


def test_profiles_differ():
    hr = [Simulator(n, demo_3min()).get_frame(with_ecg=False)["hr"] for n in ("athlete", "average", "anxious")]
    assert hr[0] < hr[1] < hr[2]
    print("ok  patient profiles differ (rest HR %s)" % [round(x) for x in hr])


if __name__ == "__main__":
    test_get_frame_5_minutes(); test_live_controls(); test_corruption_levels(); test_profiles_differ()
    print("ALL PASSED")
