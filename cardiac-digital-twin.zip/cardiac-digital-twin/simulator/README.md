# simulator/  (Person B)

Synthetic patient: hidden true physiology → ECG → measured vitals. Also the corruption injector and the datasets.

```
pip install numpy scipy pandas         # nothing else needed
python -m simulator.test_simulator     # smoke test (should print ALL PASSED)
python -m simulator.generate_datasets  # rebuild data/*.csv
```

## One-call API

```python
from simulator import Simulator, demo_5min, demo_3min

sim = Simulator("average", demo_3min())   # "athlete" | "average" | "anxious" | PatientProfile(...)
frame = sim.get_frame()                    # advances 1 second
```

`frame` is the shared dict: `t (s), hr (bpm), rr (ms), hrv (ms, RMSSD), temp (C), resp (/min), spo2 (%), bp (mmHg systolic), activity (0..1), leads_ok (bool), source ("simulated")`

Extra keys (ignore if you only want the shared dict): `ecg` (250 samples = 1 s of mV @ 250 Hz), `beats` (`[{t_ms, rr_ms, kind}]`).
`get_frame(with_truth=True)` adds `frame["truth"]`. **Never show truth to the twin.**

`Simulator.b_lines(frame)` → STM32-style `B,<t_ms>,<rr_ms>,<hr>,<hrv>,<temp>,<leads_ok>` lines for replay mode.
Units note for `docs/protocol.md`: dict `t` is **seconds**, `B,` lines use **milliseconds**.

## For D: what-if sliders (override the script live)

```python
sim.set_state(activity=0.7)              # 0..1
sim.set_state(spo2=88)                   # target SpO2 %, physiology stays coherent
sim.set_state(arrhythmia="pvc")          # pvc | afib | tachy | brady | None
sim.set_state(bp_offset=25, sleep=True)  # mmHg / bool
sim.set_lead_off(True)                   # electrode disconnect: flat ECG, leads_ok False, no beats
sim.clear_overrides()                    # back to the scripted timeline (or clear_overrides("hypoxia"))
```

## Demo script `demo_3min()` (exact timings, rehearse against these)

| Time | Segment | What should happen |
|---|---|---|
| 0:00-0:45 | rest | twin learns / shows baseline |
| 0:45-1:30 | walking | HR, resp, BP rise; **no alarm** |
| 1:30-1:45 | recovery | back to baseline |
| 1:45-2:30 | hypoxia | SpO2 → ~85, HR + resp up **at rest**; **alarm** |
| 2:30-3:00 | recovery | alarm clears |

`demo_5min()` is the full 5-minute version: rest 0:00-1:00, walking 1:00-2:00, recovery, hypoxia 2:30-3:30, recovery, PVC 4:00-4:30, AFib 4:30-4:50 (`Timeline.table()` prints it).

## For C: data in `data/`

| File | Use |
|---|---|
| `<patient>_train.csv` | 20 min healthy only (varied activity + sleep). Fit / personalize the twin here. |
| `<patient>_demo.csv` | 5-min scenario, **measured** values = what the twin sees. |
| `<patient>_demo_truth.csv` | Same 5 min, **true** values + `label`, `anomaly` (0/1), and `hr_normal` / `hr_residual_true` (what HR would have been with no hypoxia/arrhythmia). Score against this. |
| `ecg_average_demo.csv`, `ecg_average_rest_60s.csv` | 250 Hz ECG (mV) for replay / R-peak tests. |
| `average_demo_corrupt_10/25/50.csv` | corrupted copies (NaN = missing, spikes, stale values) for the fusion layer. |

Patients: `athlete`, `average`, `anxious`, `patient_04`, `patient_05` (different hidden parameters each).

### Twin design: what the data supports (tested)

Tested with plain scikit-learn regression on the healthy training files:

* **Context = activity only, one residual per vital (HR, SpO2, resp), flag at |z| > 3**: walking causes ~0-2% false alarms, hypoxia is flagged in ~90% of hypoxic seconds (almost entirely via the **SpO2 residual**; the HR residual alone is weak), healthy false alarms ~5%. A fixed "HR > 100" rule gave 82 false alarms in 300 s on the `anxious` patient during walking.
* **HR ← activity + resp + SpO2 (the plan's wording) works poorly for hypoxia**: SpO2 and resp are *inputs*, and hypoxia moves both, so the twin "explains" the higher HR and the residual mostly disappears. Healthy training data also has almost no SpO2 variation, so that coefficient is unreliable. If you keep this design, alert on the SpO2 / resp values themselves, or on the combination (SpO2 low AND resp high AND HR high at rest).
* HR lags activity by ~5-11 s (slower on the way down). A lagged / smoothed activity feature reduces false alarms at transitions.
* The generator is intentionally non-linear (concave activity response, non-linear hypoxia response, fatigue creep, asymmetric lag) so a simple twin cannot copy it exactly.

## For the fusion demo: `corrupt.py`

```python
from simulator.corrupt import Corruptor, multirate, hold_last, rmse
c = Corruptor(level=0.4, seed=1)              # level 0..0.5 = fraction of data unusable
out = c.ecg_corrupt(ecg)                      # dict: t, x (NaN = lost), valid, leads_ok, clean
bad = c.df_corrupt(measured_df)               # vitals with drops / spikes / stale / leads-off
slow = multirate(measured_df, {"temp": 0.2, "spo2": 0.5, "bp": 0.1}, jitter=0.1)
```

The clean input is never modified, so it is the ground truth for RMSE-vs-level curves.
Approximate reference numbers for the "before" curve (naive hold-last-value, HR RMSE): 2.5 bpm at level 0, 9.5 at 0.1, 15 at 0.25, 22 at 0.4, 28 at 0.5.

## Known limitations (say these honestly in the pitch)

* Only ECG and temperature are real hardware signals. Respiration, activity, SpO2 and BP are **simulated**.
* NeuroKit2 is **not** used: `ecg_simulate` takes one fixed heart rate for the whole signal, so it cannot follow a changing HR. `ecg_sim.py` is a beat-by-beat NumPy generator (P-QRS-T Gaussians, RSA, wander, mains hum, motion artifact).
* Measured HRV is RMSSD over the last 30 beats, so PVCs inflate it (realistic: a real R-R based HRV does too). AFib alone gives ~100 ms; PVC segments read 200+ ms. A's firmware could exclude ectopic beats.
* Tested by simulation only. `ecg_sim.to_adc_counts()` (for the optional stream-to-STM32 stretch goal) has **not** been tried on hardware.
* Mains hum is 50 Hz (India). Change `mains_hz` in `ECGSynth` elsewhere.
