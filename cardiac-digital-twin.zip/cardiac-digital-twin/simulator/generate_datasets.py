"""
generate_datasets.py  -  build the CSVs Person C needs (Person B)

Run from the repo root:      python -m simulator.generate_datasets

Writes to data/ (small files only):
  <patient>_train.csv         20 min of HEALTHY data, varied activity + sleep.  Fit / personalize the twin on this.
  <patient>_demo.csv          the 5-min scripted scenario, MEASURED values only (what the twin sees).
  <patient>_demo_truth.csv    same 5 minutes, TRUE values + labels + anomaly flag + hr_normal.  Score against this.
  ecg_average_demo.csv        250 Hz ECG (mV) of the 'average' patient's 5-min scenario.
  ecg_average_rest_60s.csv    60 s of clean resting ECG (replay-mode / R-peak testing).
  average_demo_corrupt_XX.csv the 'average' demo with 10 / 25 / 50 % corruption (fusion tests).

Patients: athlete, average, anxious, patient_04, patient_05  (each has different hidden parameters).
"""
import os
import numpy as np

from .patient_state import PROFILES, PatientProfile, random_profile
from .scenarios import Simulator, demo_5min, training_random, Timeline
from .corrupt import Corruptor

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def reseed(profile, seed):
    return PatientProfile(**{**profile.__dict__, "seed": seed})


def main(out=OUT):
    os.makedirs(out, exist_ok=True)
    patients = [PROFILES["athlete"], PROFILES["average"], PROFILES["anxious"],
                random_profile(4), random_profile(5)]
    written = []

    for prof in patients:
        # --- training set: healthy only, different noise realisation than the demo
        sim = Simulator(reseed(prof, prof.seed + 100), training_random(20, seed=prof.seed))
        meas, truth, _ = sim.collect()
        meas.round(3).to_csv(f"{out}/{prof.name}_train.csv", index=False)
        assert truth["anomaly"].sum() == 0            # training data must be anomaly-free

        # --- demo scenario: measured (twin input) + truth (scoring)
        sim = Simulator(prof, demo_5min())
        meas, truth, ecg = sim.collect(keep_ecg=True)
        meas.round(3).to_csv(f"{out}/{prof.name}_demo.csv", index=False)
        sim.save_truth(f"{out}/{prof.name}_demo_truth.csv")
        written += [f"{prof.name}_train.csv", f"{prof.name}_demo.csv", f"{prof.name}_demo_truth.csv"]

        if prof.name == "average":
            t = np.arange(len(ecg)) / 250.0
            np.savetxt(f"{out}/ecg_average_demo.csv", np.c_[t, ecg], delimiter=",",
                       header="t_s,ecg_mv", comments="", fmt=["%.4f", "%.4f"])
            written.append("ecg_average_demo.csv")
            for lv in (0.10, 0.25, 0.50):
                bad = Corruptor(lv, seed=int(lv * 100)).df_corrupt(meas)
                bad.round(3).to_csv(f"{out}/average_demo_corrupt_{int(lv*100):02d}.csv", index=False)
                written.append(f"average_demo_corrupt_{int(lv*100):02d}.csv")

    # clean resting ECG for replay / R-peak testing
    rest = Simulator("average", Timeline("rest").add("rest", 60), seed=42)
    _, _, ecg = rest.collect(keep_ecg=True)
    np.savetxt(f"{out}/ecg_average_rest_60s.csv", np.c_[np.arange(len(ecg)) / 250.0, ecg],
               delimiter=",", header="t_s,ecg_mv", comments="", fmt=["%.4f", "%.4f"])
    written.append("ecg_average_rest_60s.csv")

    total = sum(os.path.getsize(f"{out}/{f}") for f in written)
    print(f"wrote {len(written)} files to {out}  ({total/1e6:.1f} MB)")
    return written


if __name__ == "__main__":
    main()
