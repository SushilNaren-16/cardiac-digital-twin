"""
corrupt.py  -  Corruption injector for the sensor-fusion layer (Person B, Phase 3)

Takes CLEAN simulator output (which is the ground truth) and damages it the way real
wearables get damaged, so C's fusion layer can be scored:  RMSE vs. truth  vs.  a
naive baseline, across corruption levels 0 .. 0.5.

    level = 0.0 .. 0.5   ~ fraction of the data that is damaged / lost

Problems covered (matches problem statement #3):
  1. noise + motion artifact bursts       -> ecg_corrupt()
  2. electrode disconnect (flat, leads_ok False) -> ecg_corrupt()
  3. lost samples (random singles + burst gaps)  -> ecg_corrupt()
  4. mismatched sampling rates (ECG 250 Hz, temp 1 Hz, SpO2 0.5 Hz ...) -> multirate()
  5. corrupted vitals frames (dropout / spike / stale value) -> frame_corrupt()

Everything is seeded, so a demo run is repeatable. The clean input is NEVER modified.
"""
import numpy as np
import pandas as pd

VITAL_FIELDS = ["hr", "rr", "hrv", "temp", "resp", "spo2", "bp", "activity"]


class Corruptor:
    def __init__(self, level=0.2, seed=0):
        self.level = float(np.clip(level, 0.0, 0.5))
        self.rng = np.random.default_rng(seed)

    # ------------------------------------------------------------------ ECG
    def ecg_corrupt(self, ecg, fs=250, mode="nan"):
        """
        ecg  : 1-D clean ECG (mV)
        mode : "nan"    -> lost samples stay in place as NaN (easy to align)
               "remove" -> lost samples are deleted; returned time axis has holes

        Returns dict:
            t        time axis (s)               (holes if mode == "remove")
            x        corrupted ECG (mV)
            valid    bool mask on the ORIGINAL timeline: True = sample survived
            leads_ok bool mask on the ORIGINAL timeline: False = electrode off
            clean    the untouched input (ground truth)
        """
        rng, lv = self.rng, self.level
        x = np.array(ecg, dtype=float)
        n = len(x)
        dur = n / fs
        t_full = np.arange(n) / fs
        leads_ok = np.ones(n, bool)
        valid = np.ones(n, bool)
        if lv == 0:
            return dict(t=t_full, x=x, valid=valid, leads_ok=leads_ok, clean=np.array(ecg))

        # 1) broadband noise grows with level
        x += rng.normal(0, 0.02 + 0.35 * lv, n)

        # 2) motion-artifact bursts: slow big swings + jitter, 0.5-2 s each
        n_bursts = rng.poisson(lv * dur / 6.0)
        for _ in range(n_bursts):
            L_ = int(rng.uniform(0.5, 2.0) * fs)
            i = int(rng.integers(0, max(n - L_, 1)))
            tt = np.arange(min(L_, n - i)) / fs
            amp = rng.uniform(0.4, 1.4)
            x[i:i + len(tt)] += (amp * np.sin(2 * np.pi * rng.uniform(0.6, 2.5) * tt + rng.uniform(0, 6.28))
                                 + rng.normal(0, 0.15 * amp, len(tt)))

        # 3) electrode disconnects: flat line, leads_ok False (20% of the loss budget)
        off_budget = int(0.20 * lv * n)
        while (~leads_ok).sum() < off_budget:
            L_ = int(min(off_budget - (~leads_ok).sum(), rng.uniform(0.5, 3.0) * fs))
            L_ = max(L_, 1)
            i = int(rng.integers(0, max(n - L_, 1)))
            x[i:i + L_] = 1.4 + rng.normal(0, 0.003, len(x[i:i + L_]))     # railed baseline
            leads_ok[i:i + L_] = False

        # 4) lost samples (80% of the budget): 40% random singles, 60% burst gaps.
        #    Loops until the budget is met exactly, so level 0.5 really loses ~40% + 10% off.
        loss_budget = int(0.80 * lv * n)
        singles = int(0.4 * loss_budget)
        if singles:
            valid[rng.choice(n, singles, replace=False)] = False
        while (~valid).sum() < loss_budget:
            L_ = int(min(loss_budget - (~valid).sum(), rng.uniform(0.1, 1.5) * fs))
            L_ = max(L_, 1)
            i = int(rng.integers(0, max(n - L_, 1)))
            valid[i:i + L_] = False

        if mode == "nan":
            out = np.where(valid, x, np.nan)
            return dict(t=t_full, x=out, valid=valid, leads_ok=leads_ok, clean=np.array(ecg))
        return dict(t=t_full[valid], x=x[valid], valid=valid, leads_ok=leads_ok,
                    clean=np.array(ecg))

    # --------------------------------------------------------- vitals frames
    def frame_corrupt(self, frame):
        """Corrupt ONE shared-dict frame. Returns a copy (clean frame untouched).
        Each vital independently may: drop out (None), spike, or repeat a stale value.
        Probability per field per frame = level. If the leads are off, hr/rr/hrv are None."""
        f = dict(frame)
        rng = self.rng
        for k in VITAL_FIELDS:
            if k not in f or f[k] is None:
                continue
            if rng.random() < self.level:
                kind = rng.choice(["drop", "spike", "stale"], p=[0.5, 0.3, 0.2])
                if kind == "drop":
                    f[k] = None
                elif kind == "spike":
                    f[k] = float(f[k]) * float(rng.choice([0.4, 0.6, 1.6, 2.2]))
                else:
                    f[k] = getattr(self, "_stale", {}).get(k, f[k])
        # leads-off flag flips occasionally at high corruption
        if rng.random() < self.level * 0.3:
            f["leads_ok"] = False
            for k in ("hr", "rr", "hrv"):
                f[k] = None
        self._stale = {k: v for k, v in frame.items() if k in VITAL_FIELDS}
        return f

    def stream(self, frames):
        """Wrap a frame generator: yields corrupted copies (and skips whole frames at random)."""
        for fr in frames:
            if self.rng.random() < 0.3 * self.level:       # entire second lost
                continue
            yield self.frame_corrupt(fr)

    def df_corrupt(self, df):
        """Corrupt a measured DataFrame (columns = shared dict). Returns a new DataFrame
        with NaN where data is missing; the input is untouched."""
        rows = [self.frame_corrupt(r) for r in df.to_dict("records")]
        return pd.DataFrame(rows)


# ------------------------------------------------------------------ rate mismatch
def multirate(df, rates=None, jitter=0.0, seed=0):
    """
    Turn a 1 Hz DataFrame into signals that arrive at DIFFERENT rates (problem #3).

    rates: dict field -> Hz, e.g. {"temp": 0.2, "spo2": 0.5, "bp": 0.1, "resp": 0.5}
           (anything not listed stays at the frame rate of `df`)
    jitter: std (s) of random timestamp jitter (late / early arrival)

    Returns dict field -> DataFrame[t, value] with only the samples that "arrived".
    The fusion layer must align these onto one timeline (hold / interpolate / Kalman).
    """
    rates = rates or {"temp": 0.2, "spo2": 0.5, "bp": 0.1, "resp": 0.5}
    rng = np.random.default_rng(seed)
    base_hz = 1.0 / float(np.median(np.diff(df["t"].values)))
    out = {}
    for k in VITAL_FIELDS:
        if k not in df:
            continue
        step = max(int(round(base_hz / rates.get(k, base_hz))), 1)
        sub = df.iloc[::step][["t", k]].copy()
        if jitter > 0:
            sub["t"] = sub["t"] + rng.normal(0, jitter, len(sub))
        out[k] = sub.rename(columns={k: "value"}).reset_index(drop=True)
    return out


def hold_last(series_df, t_grid):
    """Baseline for the fusion score: sample-and-hold a slow signal onto a fast grid."""
    s = series_df.sort_values("t")
    idx = np.searchsorted(s["t"].values, t_grid, side="right") - 1
    idx = np.clip(idx, 0, len(s) - 1)
    return s["value"].values[idx]


def rmse(estimate, truth):
    """RMSE ignoring NaNs - use for 'error vs corruption level' curves."""
    e, t = np.asarray(estimate, float), np.asarray(truth, float)
    m = ~(np.isnan(e) | np.isnan(t))
    return float(np.sqrt(np.mean((e[m] - t[m]) ** 2))) if m.any() else float("nan")
