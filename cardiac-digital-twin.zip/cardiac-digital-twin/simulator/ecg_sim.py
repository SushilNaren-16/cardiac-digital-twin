"""
ecg_sim.py  -  ECG generator (Person B)

Generates a continuous ECG (mV) at fs = 250 Hz (same rate as the STM32 ADC),
one chunk at a time, so HR / HRV / respiration can change LIVE.

How it works
  1. RR-interval generator: RR = 60000/HR  +  respiratory sinus arrhythmia (RSA, a
     sine at the breathing rate)  +  beat-to-beat jitter. Amplitudes are calibrated
     so the RMSSD of the RR series ~ the requested HRV.
  2. Rhythm modes: normal | pvc | afib | tachy | brady (tachy/brady only change HR,
     which the physiology layer already sets).
  3. Beat morphology: sum of Gaussians (P, Q, R, S, T). QT scales with sqrt(RR).
     PVC = wide, tall, inverted-T beat with a compensatory pause. AFib = no P wave,
     small fibrillatory waves, irregular RR.
  4. Realism: baseline wander (slow + respiration-linked), 50 Hz powerline hum,
     white noise, and motion artifact that grows with activity.

NOTE: neurokit2.ecg_simulate() takes ONE fixed heart rate for the whole signal, so it
cannot follow a changing HR second by second. This generator can. neurokit2 is still
handy offline (e.g. to compare shapes) but is not required.
"""
import numpy as np
from scipy.signal import lfilter


class ECGSynth:
    def __init__(self, fs=250, seed=0, noise=1.0, mains_hz=50.0):
        self.fs = fs
        self.rng = np.random.default_rng(seed + 12345)
        self.noise = noise
        self.mains_hz = mains_hz
        self.t = 0.0                    # time rendered so far (s)
        self.next_r = 0.35              # time of the next R peak (s)
        self.beats = []                 # pending / recent beats {t, rr, kind}
        self._rsa_phase = 0.0
        self._forced_rr = None          # used for PVC compensatory pause
        self._resp_phase = 0.0          # for respiration-linked baseline wander
        self._motion_zi = np.zeros(1)   # filter state for motion artifact
        self.last_rr = 60000 / 70

    # ------------------------------------------------------------------
    # RR interval generation
    # ------------------------------------------------------------------
    def _next_rr(self, hr, hrv, resp, rhythm):
        """Return (rr_ms_from_previous_beat_to_next, kind_of_next_beat)."""
        base = 60000.0 / max(hr, 30.0)

        if self._forced_rr is not None:                 # compensatory pause after PVC
            rr, self._forced_rr = self._forced_rr, None
            return rr, "normal"

        if rhythm == "afib":                            # irregularly irregular
            s = (hrv / np.sqrt(2)) / max(base, 1.0)
            rr = base * np.exp(self.rng.normal(0, np.clip(s, 0.08, 0.35)))
            return float(np.clip(rr, 280, 1600)), "afib"

        # normal sinus rhythm with RSA + jitter, calibrated to RMSSD ~ hrv
        f = resp / 60.0
        k = max(np.sqrt(2) * abs(np.sin(np.pi * f * base / 1000.0)), 0.35)
        rsa_amp = (hrv * np.sqrt(0.6)) / k
        jit_sd = (hrv * np.sqrt(0.4)) / np.sqrt(2)
        self._rsa_phase += 2 * np.pi * f * base / 1000.0
        rr = base + rsa_amp * np.sin(self._rsa_phase) + self.rng.normal(0, jit_sd)
        rr = float(np.clip(rr, 0.55 * base, 1.6 * base))

        if rhythm == "pvc" and self.rng.random() < 0.10:
            self._forced_rr = max(2 * base - 0.62 * base, 0.6 * base)   # pause after PVC
            return 0.62 * base, "pvc"                                   # premature beat
        return rr, "normal"

    # ------------------------------------------------------------------
    # beat templates
    # ------------------------------------------------------------------
    @staticmethod
    def _beat(tau, rr_s, kind):
        """ECG contribution (mV) of one beat at times tau (s) relative to its R peak."""
        g = lambda mu, a, s: a * np.exp(-0.5 * ((tau - mu) / s) ** 2)
        sq = np.sqrt(rr_s)
        if kind == "pvc":
            return (g(0.0, 1.25, 0.028) + g(0.055, -0.45, 0.030)
                    + g(0.30 * sq, -0.45, 0.065))
        y = (g(0.0, 1.00, 0.010) + g(-0.036, -0.10, 0.008) + g(0.030, -0.22, 0.009)
             + g(0.27 * sq, 0.30, 0.045 * sq))
        if kind != "afib":
            y = y + g(-0.17 * sq, 0.12, 0.022)          # P wave (absent in AFib)
        return y

    # ------------------------------------------------------------------
    def render(self, dur, hr, hrv, resp, rhythm=None, activity=0.0, lead_off=False):
        """
        Advance the ECG by `dur` seconds.
        Returns (ecg_mv: ndarray[int(dur*fs)], beats: list of new beat dicts
                 {t_ms, rr_ms, kind} whose R peak fell inside this chunk).
        """
        fs, n = self.fs, int(round(dur * self.fs))
        t0, t1 = self.t, self.t + dur
        # schedule beats a little beyond the chunk so T waves are complete
        while self.next_r < t1 + 0.8:
            rr_ms, kind = self._next_rr(hr, hrv, resp, rhythm)
            self.beats.append(dict(t=self.next_r, rr=rr_ms, kind=kind))
            self.next_r += rr_ms / 1000.0
        ts = t0 + np.arange(n) / fs
        x = np.zeros(n)
        new_beats = []
        prev_t = None
        for b in self.beats:
            if t0 - 0.7 <= b["t"] < t1 + 0.7:
                x += self._beat(ts - b["t"], max(b["rr"], 400) / 1000.0, b["kind"])
            if t0 <= b["t"] < t1:
                new_beats.append(dict(t_ms=b["t"] * 1000.0, rr_ms=b["rr"], kind=b["kind"]))
        self.beats = [b for b in self.beats if b["t"] > t0 - 1.0]

        if rhythm == "afib":                                # fibrillatory f-waves
            x += 0.03 * np.sin(2 * np.pi * 6.0 * ts + 1.3) * (0.6 + 0.4 * self.rng.random())

        # ---- baseline wander (slow + respiration-linked)
        f_resp = resp / 60.0
        ph = self._resp_phase + 2 * np.pi * f_resp * np.arange(n) / fs
        self._resp_phase = float(ph[-1] + 2 * np.pi * f_resp / fs) % (2 * np.pi)
        x += 0.10 * np.sin(2 * np.pi * 0.17 * ts + 0.7) + 0.05 * np.sin(ph)

        # ---- noise: white + mains hum + motion artifact (grows with activity)
        x += self.rng.normal(0, 0.015 * self.noise, n)
        x += 0.01 * self.noise * np.sin(2 * np.pi * self.mains_hz * ts)
        if activity > 0.05:
            w = self.rng.normal(0, 1, n)
            slow, self._motion_zi = lfilter([0.02], [1, -0.98], w, zi=self._motion_zi)
            x += (3.0 * activity ** 2) * slow
            if activity > 0.4 and self.rng.random() < 0.25 * activity:   # occasional spike burst
                i = self.rng.integers(0, max(n - 20, 1))
                x[i:i + 20] += self.rng.normal(0, 0.25 * activity, min(20, n - i))

        if lead_off:                                        # electrode disconnected: flat rail + hum
            x = 0.02 * np.sin(2 * np.pi * self.mains_hz * ts) + 0.005 * self.rng.standard_normal(n) + 1.4

        self.t = t1
        if new_beats:
            self.last_rr = new_beats[-1]["rr_ms"]
        return x, new_beats


def to_adc_counts(ecg_mv, bits=12, gain=100.0, vref=3.3):
    """
    Convert mV -> STM32 ADC counts the way an AD8232 module would present it:
    output = 1.5 V mid-rail + gain * ECG. (Default AD8232 board gain is about 100.)
    Use ONLY for the stretch goal of streaming simulated ECG to the STM32.
    """
    volts = 1.5 + np.asarray(ecg_mv) * 1e-3 * gain
    counts = np.round(volts / vref * (2 ** bits - 1))
    return np.clip(counts, 0, 2 ** bits - 1).astype(int)
